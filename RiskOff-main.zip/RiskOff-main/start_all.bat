@echo off
title RiskOff Launcher
echo ==================================================
echo   Starting RISKOFF - AI Contract Analyzer
echo ==================================================

echo [1/3] Starting Python FastAPI AI Microservice on Port 8000...
start "RiskOff AI Service (Port 8000)" cmd /k "cd ai-service && .\venv\Scripts\activate && python -m uvicorn main:app --reload --port 8000"

timeout /t 3 /nobreak >nul

echo [2/3] Starting Node.js Express Backend API on Port 5000...
start "RiskOff Node Backend (Port 5000)" cmd /k "cd server && npm run dev"

timeout /t 2 /nobreak >nul

echo [3/3] Starting React Frontend on Port 5173...
start "RiskOff React UI (Port 5173)" cmd /k "cd client && npm run dev"

echo.
echo ==================================================
echo   All 3 RiskOff services started!
echo   Frontend: http://localhost:5173
echo   Backend:  http://localhost:5000/api/health
echo   AI Micro: http://localhost:8000/health
echo ==================================================
