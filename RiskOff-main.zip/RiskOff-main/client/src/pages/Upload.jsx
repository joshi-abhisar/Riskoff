import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { contractsAPI, analysisAPI } from '../services/api';
import FileUpload from '../components/FileUpload';
import LoadingState from '../components/LoadingState';
import { ShieldCheck, ArrowLeft, AlertCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const Upload = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleStartAnalysis = async (file, language) => {
    setIsAnalyzing(true);
    setErrorMessage('');

    try {
      // 1. Upload Contract File
      const formData = new FormData();
      formData.append('file', file);

      const uploadRes = await contractsAPI.upload(formData);
      if (!uploadRes.data.success) {
        throw new Error(uploadRes.data.message || 'Upload failed.');
      }

      const contractId = uploadRes.data.contract.id;

      // 2. Trigger Complete Analysis Pipeline with Selected Language
      const analyzeRes = await analysisAPI.analyze(contractId, language);
      if (!analyzeRes.data.success) {
        throw new Error(analyzeRes.data.message || 'Analysis processing failed.');
      }

      // 3. Navigate directly to the Analysis Report View
      navigate(`/analysis/${contractId}`);

    } catch (err) {
      console.error('Contract analysis failure:', err);
      const msg = err.response?.data?.message || err.message || 'An error occurred during analysis.';
      setErrorMessage(msg);
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      
      {/* Back button */}
      <Link
        to="/dashboard"
        className="inline-flex items-center space-x-2 text-xs font-semibold text-slate-400 hover:text-slate-200 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Dashboard</span>
      </Link>

      <div className="text-center max-w-2xl mx-auto mb-8">
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">Analyze Your Contract</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-2">
          Upload any legal contract to detect unfavorable clauses, hidden obligations, and review simple explanations in your chosen language.
        </p>
      </div>

      {errorMessage && (
        <div className="mb-6 max-w-2xl mx-auto flex items-start space-x-3 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400 mt-0.5" />
          <div>
            <p className="font-semibold text-rose-200">Analysis Error</p>
            <p className="text-xs text-rose-300 mt-0.5">{errorMessage}</p>
          </div>
        </div>
      )}

      {isAnalyzing ? (
        <LoadingState />
      ) : (
        <FileUpload onStartAnalysis={handleStartAnalysis} isAnalyzing={isAnalyzing} />
      )}

    </div>
  );
};

export default Upload;
