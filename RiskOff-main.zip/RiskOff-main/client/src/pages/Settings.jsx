import React, { useState, useEffect } from 'react';
import { systemAPI } from '../services/api';
import {
  Server,
  Database,
  Cpu,
  Eye,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Info,
  ShieldCheck,
  Zap,
  Terminal,
  Layers
} from 'lucide-react';

const Settings = () => {
  const [healthData, setHealthData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchHealth = async () => {
    try {
      setRefreshing(true);
      const res = await systemAPI.getHealth();
      setHealthData(res.data);
    } catch (err) {
      console.error('Failed to fetch system health:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchHealth();
  }, []);

  const aiDetails = healthData?.aiService?.details;
  const isOcrReady = aiDetails?.ocr?.available;
  const isOllamaReady = aiDetails?.ollama?.available;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">System Diagnostics & Environment</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time status of local backend, database, document OCR, and AI pipelines.
          </p>
        </div>
        <button
          onClick={fetchHealth}
          disabled={refreshing}
          className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
          <span>Refresh Status</span>
        </button>
      </div>

      {/* Grid of Microservices Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* 1. Node / Express API */}
        <div className="p-6 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Server className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Node.js Express Backend</h3>
                <p className="text-[11px] text-slate-400">Port 5000 • Auth, JWT & Routing</p>
              </div>
            </div>
            <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold uppercase">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Online</span>
            </span>
          </div>
          <div className="text-xs font-mono text-slate-400 bg-navy-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <p>API Endpoint: /api/v1</p>
            <p>Rate Limiter: Enabled (300 req / 15m)</p>
            <p>Security Headers: Helmet Active</p>
          </div>
        </div>

        {/* 2. MongoDB Database */}
        <div className="p-6 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">MongoDB Database</h3>
                <p className="text-[11px] text-slate-400">Users, Contracts & Analysis Storage</p>
              </div>
            </div>
            {healthData?.database?.connected ? (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold uppercase">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Connected</span>
              </span>
            ) : (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] font-bold uppercase">
                <XCircle className="w-3.5 h-3.5" />
                <span>Disconnected</span>
              </span>
            )}
          </div>
          <div className="text-xs font-mono text-slate-400 bg-navy-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <p>URI: {healthData?.database?.uri || 'mongodb://127.0.0.1:27017/riskoff'}</p>
            <p>Collections: users, contracts, analyses</p>
            <p>Isolation: User Ownership Guarded</p>
          </div>
        </div>

        {/* 3. Python FastAPI AI Engine */}
        <div className="p-6 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-2xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">FastAPI AI Microservice</h3>
                <p className="text-[11px] text-slate-400">Port 8000 • PyMuPDF & Rule Engine</p>
              </div>
            </div>
            {healthData?.aiService?.status === 'online' ? (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold uppercase">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Online</span>
              </span>
            ) : (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[11px] font-bold uppercase">
                <XCircle className="w-3.5 h-3.5" />
                <span>Offline</span>
              </span>
            )}
          </div>
          <div className="text-xs font-mono text-slate-400 bg-navy-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <p>Provider: {aiDetails?.configured_ai_provider || 'rule_based'}</p>
            <p>Digital PDF Parser: PyMuPDF (fitz)</p>
            <p>Languages: 11 Supported (Hindi, Hinglish, Bengali...)</p>
          </div>
        </div>

        {/* 4. Tesseract OCR Engine */}
        <div className="p-6 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Tesseract OCR</h3>
                <p className="text-[11px] text-slate-400">Free, Local Scanned Image Extraction</p>
              </div>
            </div>
            {isOcrReady ? (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold uppercase">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Ready</span>
              </span>
            ) : (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-bold uppercase">
                <Info className="w-3.5 h-3.5" />
                <span>Optional / Not Found</span>
              </span>
            )}
          </div>
          <div className="text-xs font-mono text-slate-400 bg-navy-950 p-3 rounded-xl border border-slate-800 space-y-1">
            <p>Engine: Local Tesseract</p>
            <p className="truncate">Path: {aiDetails?.ocr?.binary_path || 'System PATH / Auto-detect'}</p>
            <p className="text-[11px] text-slate-500">{aiDetails?.ocr?.message}</p>
          </div>
        </div>

      </div>

      {/* Architecture Overview */}
      <div className="p-8 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center space-x-2 text-emerald-400">
          <Layers className="w-5 h-5" />
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-200">
            System Architecture & Zero-Cost Pipeline
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          RiskOff runs entirely on your local machine with zero external paid APIs. When a contract is uploaded:
        </p>
        <div className="p-4 rounded-2xl bg-navy-950 border border-slate-800 font-mono text-xs text-slate-300 space-y-1.5 leading-relaxed overflow-x-auto">
          <p className="text-emerald-400">React UI (Port 5173) ➔ Node/Express API (Port 5000) ➔ MongoDB (Local)</p>
          <p className="text-cyan-400">Node/Express ➔ Python FastAPI (Port 8000) ➔ PyMuPDF / Tesseract OCR</p>
          <p className="text-amber-400">FastAPI ➔ Rule-Based NLP & Multi-Language Engine (11 Languages)</p>
          <p className="text-slate-500">Optional: FastAPI ➔ Local Ollama LLM (http://localhost:11434)</p>
        </div>
      </div>

    </div>
  );
};

export default Settings;
