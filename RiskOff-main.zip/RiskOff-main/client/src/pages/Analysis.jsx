import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { contractsAPI, analysisAPI } from '../services/api';
import ScoreCard from '../components/ScoreCard';
import RiskCard from '../components/RiskCard';
import MisleadingCard from '../components/MisleadingCard';
import ClauseCard from '../components/ClauseCard';
import {
  FileText,
  ArrowLeft,
  Globe,
  AlertTriangle,
  EyeOff,
  ShieldCheck,
  CheckCircle2,
  ListChecks,
  FileCode,
  Printer,
  Download,
  Trash2,
  Loader2,
  HelpCircle,
  Sparkles,
  ChevronDown,
  Layers
} from 'lucide-react';

const LANGUAGES = [
  { code: 'en', name: 'English', native: 'English' },
  { code: 'hi', name: 'Hindi (हिंदी)', native: 'हिंदी' },
  { code: 'hinglish', name: 'Hinglish', native: 'Hinglish' },
  { code: 'bn', name: 'Bengali (বাংলা)', native: 'বাংলা' },
  { code: 'mr', name: 'Marathi (मराठी)', native: 'मराठी' },
  { code: 'ta', name: 'Tamil (தமிழ்)', native: 'தமிழ்' },
  { code: 'te', name: 'Telugu (తెలుగు)', native: 'తెలుగు' },
  { code: 'gu', name: 'Gujarati (ગુજરાતી)', native: 'ગુજરાતી' },
  { code: 'kn', name: 'Kannada (ಕನ್ನಡ)', native: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam (മലയാളം)', native: 'മലയാളം' },
  { code: 'pa', name: 'Punjabi (ਪੰਜਾਬੀ)', native: 'ਪੰਜਾਬੀ' },
];

const Analysis = () => {
  const { contractId } = useParams();
  const navigate = useNavigate();

  const [contract, setContract] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [reanalyzing, setReanalyzing] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [activeTab, setActiveTab] = useState('overview'); // overview, risks, misleading, clauses, text
  const [clauseFilter, setClauseFilter] = useState('ALL');

  const fetchAnalysisData = async () => {
    try {
      setLoading(true);
      const res = await contractsAPI.getById(contractId);
      if (res.data.success) {
        setContract(res.data.contract);
        setAnalysis(res.data.analysis);
        if (res.data.analysis?.preferredLanguage) {
          setSelectedLanguage(res.data.analysis.preferredLanguage);
        }
      }
    } catch (err) {
      console.error('Failed to load contract analysis:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalysisData();
  }, [contractId]);

  const handleLanguageChange = async (newLang) => {
    setSelectedLanguage(newLang);
    try {
      setReanalyzing(true);
      const res = await analysisAPI.analyze(contractId, newLang);
      if (res.data.success) {
        setAnalysis(res.data.analysis);
      }
    } catch (err) {
      alert('Failed to re-analyze in selected language: ' + (err.response?.data?.message || err.message));
    } finally {
      setReanalyzing(false);
    }
  };

  const handleExportReport = () => {
    if (!contract || !analysis) return;

    let md = `# RISKOFF ANALYSIS REPORT\n\n`;
    md += `**Document:** ${contract.fileName}\n`;
    md += `**Explanation Language:** ${analysis.languageName || selectedLanguage}\n`;
    md += `**Date:** ${new Date().toLocaleDateString()}\n\n`;
    md += `---\n\n`;
    md += `## 1. SCORES\n`;
    md += `- **RiskOff Risk Indicator:** ${analysis.riskScore} / 100 (${analysis.riskLevel})\n`;
    md += `- **Transparency Score:** ${analysis.transparencyScore} / 100 (${analysis.transparencyLevel})\n\n`;
    md += `## 2. CONTRACT SUMMARY\n${analysis.summary}\n\n`;
    md += `## 3. KEY TAKEAWAYS\n`;
    analysis.keyTakeaways?.forEach((k, i) => {
      md += `${i + 1}. ${k}\n`;
    });
    md += `\n## 4. WHAT YOU SHOULD CLARIFY\n`;
    analysis.recommendations?.forEach((r, i) => {
      md += `${i + 1}. ${r}\n`;
    });
    md += `\n## 5. DETECTED HIGH-RISK CLAUSES (${analysis.risks?.length || 0})\n`;
    analysis.risks?.forEach((r, i) => {
      md += `### ${i + 1}. [${r.severity}] ${r.title}\n`;
      md += `- **Explanation:** ${r.explanation}\n`;
      md += `- **Why It Matters:** ${r.whyItMatters}\n`;
      md += `- **Recommendation:** ${r.recommendation}\n`;
      md += `- **Original Clause:** "${r.originalText}"\n\n`;
    });
    md += `\n---\n*Disclaimer: RiskOff provides automated informational analysis and is not a substitute for professional legal advice.*\n`;

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `RiskOff_Report_${contract.fileName.replace(/\.[^/.]+$/, '')}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to permanently delete this contract and analysis?')) {
      return;
    }
    try {
      await contractsAPI.delete(contractId);
      navigate('/dashboard');
    } catch (err) {
      alert('Failed to delete contract.');
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto py-24 text-center">
        <Loader2 className="w-10 h-10 text-emerald-400 animate-spin mx-auto mb-4" />
        <h3 className="text-lg font-bold text-white">Loading Analysis Report...</h3>
      </div>
    );
  }

  if (!contract || !analysis) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center space-y-4">
        <FileText className="w-12 h-12 text-slate-600 mx-auto" />
        <h2 className="text-xl font-bold text-white">Analysis Not Found</h2>
        <p className="text-xs text-slate-400">
          This contract has not been analyzed yet or you do not have permission to view it.
        </p>
        <Link
          to="/dashboard"
          className="inline-block px-5 py-2.5 rounded-xl bg-emerald-500 text-navy-950 font-bold text-xs"
        >
          Return to Dashboard
        </Link>
      </div>
    );
  }

  // Filter clauses by category
  const categories = ['ALL', ...Array.from(new Set(analysis.importantClauses?.map((c) => c.category) || []))];
  const filteredClauses = (analysis.importantClauses || []).filter(
    (c) => clauseFilter === 'ALL' || c.category === clauseFilter
  );

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 print:py-0 print:px-0">
      
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <Link
          to="/dashboard"
          className="inline-flex items-center space-x-2 text-xs font-semibold text-slate-400 hover:text-slate-200 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </Link>

        <div className="flex flex-wrap items-center gap-3">
          
          {/* Language Switcher */}
          <div className="flex items-center space-x-2 bg-navy-900 border border-slate-700/80 rounded-xl px-3 py-1.5 shadow-sm">
            <Globe className="w-4 h-4 text-emerald-400" />
            <select
              value={selectedLanguage}
              onChange={(e) => handleLanguageChange(e.target.value)}
              disabled={reanalyzing}
              className="bg-transparent text-xs font-semibold text-slate-200 focus:outline-none cursor-pointer pr-2"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="bg-navy-900 text-slate-200">
                  {l.name}
                </option>
              ))}
            </select>
            {reanalyzing && <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />}
          </div>

          <button
            onClick={handleExportReport}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Markdown</span>
          </button>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-slate-700"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>

          <button
            onClick={handleDelete}
            className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold flex items-center space-x-1.5 transition-colors border border-rose-500/30"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete</span>
          </button>

        </div>
      </div>

      {/* Contract Header Card */}
      <div className="p-6 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Automated Analysis Completed ({analysis.languageName || 'English'})</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">{contract.fileName}</h1>
          <p className="text-xs text-slate-400">
            Uploaded on {new Date(contract.createdAt).toLocaleDateString()} • {(contract.fileSize / 1024).toFixed(1)} KB • AI Provider: <span className="font-mono text-emerald-400 uppercase">{analysis.aiProvider}</span>
          </p>
        </div>

        {/* Quick Badges */}
        <div className="flex items-center space-x-4 border-t md:border-t-0 md:border-l border-slate-800 pt-4 md:pt-0 md:pl-6">
          <div className="text-center">
            <span className="text-2xl font-black text-rose-400">{analysis.risks?.length || 0}</span>
            <p className="text-[11px] text-slate-400 font-medium">Risk Flags</p>
          </div>
          <div className="text-center border-l border-slate-800 pl-4">
            <span className="text-2xl font-black text-amber-400">{analysis.potentiallyMisleadingClauses?.length || 0}</span>
            <p className="text-[11px] text-slate-400 font-medium">Misleading</p>
          </div>
          <div className="text-center border-l border-slate-800 pl-4">
            <span className="text-2xl font-black text-cyan-400">{analysis.importantClauses?.length || 0}</span>
            <p className="text-[11px] text-slate-400 font-medium">Clauses</p>
          </div>
        </div>
      </div>

      {/* Visual Risk & Transparency Scores */}
      <ScoreCard
        riskScore={analysis.riskScore}
        riskLevel={analysis.riskLevel}
        transparencyScore={analysis.transparencyScore}
        transparencyLevel={analysis.transparencyLevel}
      />

      {/* Navigation Tabs */}
      <div className="border-b border-slate-800 flex items-center space-x-2 sm:space-x-4 overflow-x-auto pb-1 text-xs sm:text-sm font-semibold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center space-x-2 ${
            activeTab === 'overview'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Executive Summary & Takeaways</span>
        </button>

        <button
          onClick={() => setActiveTab('risks')}
          className={`pb-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center space-x-2 ${
            activeTab === 'risks'
              ? 'border-rose-400 text-rose-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>High-Risk Clauses ({analysis.risks?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('misleading')}
          className={`pb-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center space-x-2 ${
            activeTab === 'misleading'
              ? 'border-amber-400 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <EyeOff className="w-4 h-4" />
          <span>Potentially Misleading ({analysis.potentiallyMisleadingClauses?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('clauses')}
          className={`pb-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center space-x-2 ${
            activeTab === 'clauses'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>All Categorized Clauses ({analysis.importantClauses?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTab('text')}
          className={`pb-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center space-x-2 ${
            activeTab === 'text'
              ? 'border-slate-300 text-slate-200'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="w-4 h-4" />
          <span>Extracted Document Text</span>
        </button>
      </div>

      {/* TAB 1: EXECUTIVE SUMMARY & TAKEAWAYS */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          
          {/* Executive Summary Card */}
          <div className="p-8 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-emerald-400">
              <Sparkles className="w-5 h-5" />
              <h2 className="text-base font-bold uppercase tracking-wider text-slate-200">
                Contract Summary ({analysis.languageName || 'Selected Language'})
              </h2>
            </div>
            <p className="text-base text-slate-200 leading-relaxed font-normal bg-slate-800/40 p-5 rounded-2xl border border-slate-700/80">
              {analysis.summary}
            </p>
          </div>

          {/* Key Takeaways Card */}
          <div className="p-8 rounded-3xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-cyan-400">
              <ListChecks className="w-5 h-5" />
              <h2 className="text-base font-bold uppercase tracking-wider text-slate-200">
                Key Things to Notice
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {analysis.keyTakeaways?.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/80 flex items-start space-x-3 text-sm text-slate-200"
                >
                  <div className="w-6 h-6 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 border border-cyan-500/20">
                    {idx + 1}
                  </div>
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* What You Should Clarify Recommendations */}
          <div className="p-8 rounded-3xl bg-navy-900 border border-emerald-500/30 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
              <h2 className="text-base font-bold uppercase tracking-wider text-slate-200">
                What You Should Clarify & Negotiate
              </h2>
            </div>
            <div className="space-y-3">
              {analysis.recommendations?.map((rec, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-start space-x-3 text-sm text-emerald-200"
                >
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed font-medium">{rec}</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: HIGH RISK CLAUSES */}
      {activeTab === 'risks' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Detected High-Risk Clauses</h2>
            <span className="text-xs text-slate-400">Total detected: {analysis.risks?.length || 0}</span>
          </div>

          {analysis.risks?.length === 0 ? (
            <div className="p-8 rounded-2xl bg-navy-900 border border-slate-800 text-center">
              <ShieldCheck className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
              <p className="font-semibold text-slate-200">No high-risk clauses identified.</p>
              <p className="text-xs text-slate-400 mt-1">Standard terms were detected across monitored categories.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {analysis.risks?.map((r, idx) => (
                <RiskCard key={idx} risk={r} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: POTENTIALLY MISLEADING CLAUSES */}
      {activeTab === 'misleading' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white">Potentially Misleading or One-Sided Clauses</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Clauses with vague wording, subjective approvals, or hidden obligations that deserve closer review.
              </p>
            </div>
            <span className="text-xs text-slate-400">Total: {analysis.potentiallyMisleadingClauses?.length || 0}</span>
          </div>

          {analysis.potentiallyMisleadingClauses?.length === 0 ? (
            <div className="p-8 rounded-2xl bg-navy-900 border border-slate-800 text-center">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
              <p className="font-semibold text-slate-200">No ambiguous or misleading provisions detected.</p>
              <p className="text-xs text-slate-400 mt-1">Obligations appear clearly structured.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {analysis.potentiallyMisleadingClauses?.map((m, idx) => (
                <MisleadingCard key={idx} item={m} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: ALL CATEGORIZED CLAUSES */}
      {activeTab === 'clauses' && (
        <div className="space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h2 className="text-xl font-bold text-white">Extracted Contract Clauses</h2>
            
            {/* Category Filter Pills */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-1 max-w-full">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setClauseFilter(cat)}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                    clauseFilter === cat
                      ? 'bg-emerald-500 text-navy-950 shadow-md'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredClauses.map((clause, idx) => (
              <ClauseCard key={idx} clause={clause} />
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: ORIGINAL EXTRACTED TEXT */}
      {activeTab === 'text' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Full Extracted Document Text</h2>
            <span className="text-xs text-slate-400 font-mono">
              {analysis.extractedText?.length || 0} characters
            </span>
          </div>
          <div className="p-6 rounded-3xl bg-navy-900 border border-slate-800 text-xs font-mono text-slate-300 leading-relaxed whitespace-pre-wrap max-h-[700px] overflow-y-auto">
            {analysis.extractedText || 'No text extracted.'}
          </div>
        </div>
      )}

      {/* Prominent Legal Disclaimer */}
      <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300/90 flex items-start space-x-3">
        <HelpCircle className="w-5 h-5 flex-shrink-0 text-amber-400 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-amber-200">Legal Informational Disclaimer</p>
          <p className="leading-relaxed">
            RiskOff provides automated informational analysis and does not constitute formal legal advice.
            Contract terms, risks, and scores are generated by local NLP heuristics to assist with self-review.
            For critical legal agreements, consider consulting a qualified attorney in your jurisdiction.
          </p>
        </div>
      </div>

    </div>
  );
};

export default Analysis;
