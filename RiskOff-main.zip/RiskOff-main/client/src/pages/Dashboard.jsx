import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { contractsAPI } from '../services/api';
import {
  FileText,
  Upload,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  Search,
  Trash2,
  ExternalLink,
  Plus,
  Loader2,
  Calendar,
  Filter
} from 'lucide-react';

const Dashboard = () => {
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('ALL');
  const [deletingId, setDeletingId] = useState(null);
  const navigate = useNavigate();

  const fetchContracts = async () => {
    try {
      setLoading(true);
      const res = await contractsAPI.getAll();
      if (res.data.success) {
        setContracts(res.data.contracts || []);
      }
    } catch (err) {
      console.error('Failed to fetch contracts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContracts();
  }, []);

  const handleDelete = async (e, id) => {
    e.stopPropagation();
    if (!window.confirm('Are you sure you want to delete this contract and its analysis?')) {
      return;
    }

    try {
      setDeletingId(id);
      const res = await contractsAPI.delete(id);
      if (res.data.success) {
        setContracts(contracts.filter((c) => c.id !== id));
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete contract.');
    } finally {
      setDeletingId(null);
    }
  };

  // Compute stats
  const totalCount = contracts.length;
  const criticalCount = contracts.filter((c) => c.analysis?.riskLevel === 'CRITICAL RISK').length;
  const highCount = contracts.filter((c) => c.analysis?.riskLevel === 'HIGH RISK').length;
  
  const scores = contracts
    .filter((c) => c.analysis && typeof c.analysis.riskScore === 'number')
    .map((c) => c.analysis.riskScore);
  const avgScore = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;

  // Filtered list
  const filteredContracts = contracts.filter((c) => {
    const matchesSearch = c.fileName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRisk =
      riskFilter === 'ALL' ||
      (riskFilter === 'CRITICAL' && c.analysis?.riskLevel === 'CRITICAL RISK') ||
      (riskFilter === 'HIGH' && c.analysis?.riskLevel === 'HIGH RISK') ||
      (riskFilter === 'MODERATE' && c.analysis?.riskLevel === 'MODERATE RISK') ||
      (riskFilter === 'LOW' && c.analysis?.riskLevel === 'LOW RISK');
    return matchesSearch && matchesRisk;
  });

  const getRiskBadge = (level) => {
    switch (level) {
      case 'CRITICAL RISK':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'HIGH RISK':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'MODERATE RISK':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'LOW RISK':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Contract Intelligence Dashboard</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Monitor contract safety, analyze new agreements, and review past legal risks.
          </p>
        </div>
        <Link
          to="/upload"
          className="inline-flex items-center space-x-2 px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-navy-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02]"
        >
          <Plus className="w-4 h-4" />
          <span>Analyze Contract</span>
        </Link>
      </div>

      {/* Analytics Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        <div className="p-5 rounded-2xl bg-navy-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-slate-400">Total Analyzed</span>
            <div className="p-2 rounded-xl bg-slate-800 text-emerald-400">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-white mt-3">{totalCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">Uploaded & processed</p>
        </div>

        <div className="p-5 rounded-2xl bg-navy-900 border border-rose-500/20 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-rose-300">Critical Risks</span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-rose-400 mt-3">{criticalCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">Require immediate clarification</p>
        </div>

        <div className="p-5 rounded-2xl bg-navy-900 border border-amber-500/20 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-amber-300">High Risks</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-amber-400 mt-3">{highCount}</p>
          <p className="text-[11px] text-slate-400 mt-1">One-sided / restrictive terms</p>
        </div>

        <div className="p-5 rounded-2xl bg-navy-900 border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase text-slate-400">Average Risk Score</span>
            <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <p className="text-3xl font-black text-cyan-400 mt-3">{avgScore} <span className="text-xs text-slate-500">/ 100</span></p>
          <p className="text-[11px] text-slate-400 mt-1">Across all contracts</p>
        </div>

      </div>

      {/* Contracts Table & Filters */}
      <div className="bg-navy-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h2 className="text-lg font-bold text-white">Recent Contracts & Analyses</h2>

          {/* Search and Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search contracts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-800/80 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center space-x-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700 text-xs">
              <button
                onClick={() => setRiskFilter('ALL')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  riskFilter === 'ALL' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setRiskFilter('CRITICAL')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  riskFilter === 'CRITICAL' ? 'bg-rose-500/20 text-rose-300' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Critical
              </button>
              <button
                onClick={() => setRiskFilter('HIGH')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  riskFilter === 'HIGH' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                High
              </button>
            </div>
          </div>
        </div>

        {/* Contract List */}
        {loading ? (
          <div className="py-16 text-center">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin mx-auto mb-3" />
            <p className="text-xs text-slate-400">Loading your contract records...</p>
          </div>
        ) : filteredContracts.length === 0 ? (
          <div className="py-16 text-center border-2 border-dashed border-slate-800 rounded-2xl p-8">
            <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-300">No contracts found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Upload your first contract to identify high-risk clauses and get simplified explanations.
            </p>
            <Link
              to="/upload"
              className="inline-flex items-center space-x-2 mt-4 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-navy-950 font-bold text-xs shadow-md transition-all"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Contract Now</span>
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800 bg-slate-800/30">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">Contract Document</th>
                  <th className="py-3.5 px-4 font-semibold">Risk Level</th>
                  <th className="py-3.5 px-4 font-semibold">Score</th>
                  <th className="py-3.5 px-4 font-semibold">Language</th>
                  <th className="py-3.5 px-4 font-semibold">Date</th>
                  <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredContracts.map((contract) => (
                  <tr
                    key={contract.id}
                    onClick={() => navigate(`/analysis/${contract.id}`)}
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors group"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 group-hover:border-emerald-500/40">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                            {contract.fileName}
                          </p>
                          <span className="text-[10px] text-slate-500 uppercase">
                            {contract.fileType} • {(contract.fileSize / 1024).toFixed(0)} KB
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-4">
                      {contract.analysis ? (
                        <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold border uppercase tracking-wider ${getRiskBadge(contract.analysis.riskLevel)}`}>
                          {contract.analysis.riskLevel}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-500 italic">Not Analyzed</span>
                      )}
                    </td>

                    <td className="py-4 px-4">
                      {contract.analysis ? (
                        <span className="font-bold text-slate-200">
                          {contract.analysis.riskScore} <span className="text-[10px] text-slate-500">/ 100</span>
                        </span>
                      ) : (
                        <span className="text-slate-500">-</span>
                      )}
                    </td>

                    <td className="py-4 px-4">
                      <span className="text-slate-400 capitalize">
                        {contract.analysis?.preferredLanguage || 'en'}
                      </span>
                    </td>

                    <td className="py-4 px-4 text-slate-400">
                      <div className="flex items-center space-x-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{new Date(contract.createdAt).toLocaleDateString()}</span>
                      </div>
                    </td>

                    <td className="py-4 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/analysis/${contract.id}`);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors flex items-center space-x-1 text-xs font-semibold"
                        >
                          <span>View</span>
                          <ExternalLink className="w-3 h-3 ml-0.5" />
                        </button>
                        <button
                          onClick={(e) => handleDelete(e, contract.id)}
                          disabled={deletingId === contract.id}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                          title="Delete Contract"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
};

export default Dashboard;
