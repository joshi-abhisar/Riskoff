import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  ShieldCheck,
  FileSearch,
  Languages,
  AlertTriangle,
  FileCheck2,
  Lock,
  ArrowRight,
  Sparkles,
  Scale,
  Zap,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';

const Home = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-navy-950 flex flex-col justify-between">
      
      {/* Hero Section */}
      <section className="relative pt-16 pb-24 overflow-hidden border-b border-slate-800">
        {/* Glow backdrop effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-emerald-500/10 blur-[130px] rounded-full pointer-events-none" />
        
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-6 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Zero-Cost • 100% Free & Local • Multi-Language</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.15]">
            Understand your contract <br className="hidden sm:block" />
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              before you sign.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            Upload your contract, choose your language, and get a simple explanation of important clauses, potential risks, and terms that may need clarification.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to={isAuthenticated ? "/upload" : "/register"}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-navy-950 font-bold text-base shadow-xl shadow-emerald-500/20 transition-all duration-200 hover:scale-[1.02] flex items-center justify-center space-x-2"
            >
              <span>Analyze My Contract</span>
              <ArrowRight className="w-5 h-5" />
            </Link>
            
            <a
              href="#how-it-works"
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold text-base border border-slate-700 transition-colors flex items-center justify-center space-x-2"
            >
              <span>How It Works</span>
            </a>
          </div>

          {/* Quick Metrics Bar */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="p-4 rounded-2xl bg-navy-900/80 border border-slate-800 text-center">
              <span className="text-2xl font-black text-emerald-400">20+</span>
              <p className="text-xs text-slate-400 mt-0.5">Clause Categories</p>
            </div>
            <div className="p-4 rounded-2xl bg-navy-900/80 border border-slate-800 text-center">
              <span className="text-2xl font-black text-emerald-400">11</span>
              <p className="text-xs text-slate-400 mt-0.5">Languages (Hindi/Hinglish)</p>
            </div>
            <div className="p-4 rounded-2xl bg-navy-900/80 border border-slate-800 text-center">
              <span className="text-2xl font-black text-emerald-400">100%</span>
              <p className="text-xs text-slate-400 mt-0.5">Free & Local AI</p>
            </div>
            <div className="p-4 rounded-2xl bg-navy-900/80 border border-slate-800 text-center">
              <span className="text-2xl font-black text-emerald-400">0 ms</span>
              <p className="text-xs text-slate-400 mt-0.5">Cloud API Latency</p>
            </div>
          </div>

        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-navy-900/50 border-b border-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">How RiskOff Works</h2>
            <p className="text-sm text-slate-400 mt-2">
              Three simple steps to transform dense legalese into plain language you can trust.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Step 1 */}
            <div className="p-8 rounded-3xl bg-navy-900 border border-slate-800 hover:border-slate-700 transition-all relative group">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-black text-lg mb-6 border border-emerald-500/20 group-hover:scale-110 transition-transform">
                1
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Upload Contract</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Drop your PDF, scanned image (PNG/JPG), or text file. Select your preferred explanation language (e.g. Hindi, Hinglish, Bengali, English).
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-8 rounded-3xl bg-navy-900 border border-slate-800 hover:border-slate-700 transition-all relative group">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center font-black text-lg mb-6 border border-teal-500/20 group-hover:scale-110 transition-transform">
                2
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Automated NLP Analysis</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                PyMuPDF & Tesseract OCR extract digital text. The rule engine analyzes termination, payment, IP, indemnity, and unfair provisions.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-8 rounded-3xl bg-navy-900 border border-slate-800 hover:border-slate-700 transition-all relative group">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-black text-lg mb-6 border border-cyan-500/20 group-hover:scale-110 transition-transform">
                3
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Review & Understand</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Get your Risk Indicator score, Transparency Score, executive summary, highlighted danger flags, and specific negotiation points.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-20 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Built for Freelancers, Creators & Gig Workers</h2>
          <p className="text-sm text-slate-400 mt-2">
            Everything you need to safeguard your time, rights, and compensation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800">
            <FileSearch className="w-8 h-8 text-emerald-400 mb-4" />
            <h4 className="text-base font-bold text-white mb-1">Contract Analysis</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Automatic categorization of 20+ clause types including notice periods, payment milestones, working hours, and liabilities.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800">
            <Zap className="w-8 h-8 text-teal-400 mb-4" />
            <h4 className="text-base font-bold text-white mb-1">OCR for Scanned Documents</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Built-in Tesseract OCR scans paper contracts, photo uploads, and scanned PDFs locally with zero cloud transmission.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800">
            <Languages className="w-8 h-8 text-cyan-400 mb-4" />
            <h4 className="text-base font-bold text-white mb-1">11 Indian & Global Languages</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Read simple summaries in Hindi, Hinglish, Bengali, Marathi, Tamil, Telugu, Gujarati, Kannada, Malayalam, Punjabi, or English.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800">
            <AlertTriangle className="w-8 h-8 text-rose-400 mb-4" />
            <h4 className="text-base font-bold text-white mb-1">High-Risk Detection</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Instantly flags unilateral termination without notice, unlimited liability, broad IP grabs, and perpetual non-compete traps.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800">
            <Scale className="w-8 h-8 text-amber-400 mb-4" />
            <h4 className="text-base font-bold text-white mb-1">Misleading Clause Alerts</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Highlights vague approval criteria, subjective satisfaction clauses, and disguised employee-style restrictions.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800">
            <Lock className="w-8 h-8 text-emerald-400 mb-4" />
            <h4 className="text-base font-bold text-white mb-1">Private & User Isolated</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              JWT authentication ensures that only you can access your contracts, with complete file deletion whenever requested.
            </p>
          </div>

        </div>
      </section>

      {/* Legal Safety Disclaimer Footer */}
      <footer className="bg-navy-900 border-t border-slate-800 py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center space-x-2 text-xs text-amber-400/90 bg-amber-500/10 border border-amber-500/20 px-4 py-2 rounded-xl">
            <HelpCircle className="w-4 h-4 flex-shrink-0" />
            <span>
              <strong>Legal Disclaimer:</strong> RiskOff provides automated informational analysis and is not a substitute for professional legal advice.
            </span>
          </div>
          <p className="text-xs text-slate-500">
            &copy; {new Date().getFullYear()} RiskOff — Understand your contract before you sign. Free & Open-Source.
          </p>
        </div>
      </footer>

    </div>
  );
};

export default Home;
