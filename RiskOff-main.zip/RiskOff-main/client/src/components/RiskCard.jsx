import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, HelpCircle, ShieldAlert, CheckCircle, FileText } from 'lucide-react';

const RiskCard = ({ risk }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const getSeverityBadge = (sev) => {
    switch (sev?.toUpperCase()) {
      case 'CRITICAL':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
      case 'HIGH':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'MEDIUM':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
  };

  return (
    <div className="rounded-2xl bg-navy-900 border border-slate-800 hover:border-slate-700/80 shadow-md overflow-hidden transition-all duration-200">
      {/* Header Bar */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="p-5 flex items-center justify-between cursor-pointer bg-slate-800/40 hover:bg-slate-800/70 select-none"
      >
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-amber-400">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold border uppercase tracking-wider ${getSeverityBadge(risk.severity)}`}>
                {risk.severity || 'HIGH'}
              </span>
              <span className="text-xs text-slate-400 font-medium">Category: {risk.category}</span>
              {risk.page && (
                <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  Page {risk.page}
                </span>
              )}
            </div>
            <h4 className="text-base font-bold text-slate-100 mt-1">{risk.title}</h4>
          </div>
        </div>

        <button className="p-2 rounded-lg text-slate-400 hover:text-white">
          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="p-6 space-y-5 border-t border-slate-800/80 bg-navy-900/90 text-sm">
          
          {/* Simple Explanation */}
          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span>Simple Explanation</span>
            </h5>
            <p className="text-slate-200 leading-relaxed bg-slate-800/30 p-3 rounded-xl border border-slate-800">
              {risk.explanation}
            </p>
          </div>

          {/* Why It Matters */}
          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Why It Matters</span>
            </h5>
            <p className="text-slate-300 leading-relaxed bg-amber-500/5 p-3 rounded-xl border border-amber-500/20 text-amber-200/90">
              {risk.whyItMatters}
            </p>
          </div>

          {/* What to Clarify / Recommendation */}
          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>What You Should Clarify / Negotiate</span>
            </h5>
            <p className="text-emerald-300 leading-relaxed bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/30 font-medium">
              {risk.recommendation}
            </p>
          </div>

          {/* Original Clause Text */}
          {risk.originalText && (
            <div className="pt-2 border-t border-slate-800">
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>Original Contract Text</span>
              </h5>
              <div className="p-3 rounded-xl bg-navy-950 border border-slate-800/90 text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed">
                "{risk.originalText}"
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
};

export default RiskCard;
