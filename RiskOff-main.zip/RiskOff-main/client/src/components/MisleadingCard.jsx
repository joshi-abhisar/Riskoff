import React, { useState } from 'react';
import { EyeOff, AlertCircle, HelpCircle, CheckCircle, FileText, ChevronDown, ChevronUp } from 'lucide-react';

const MisleadingCard = ({ item }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="rounded-2xl bg-navy-900 border border-amber-500/30 hover:border-amber-500/50 shadow-lg overflow-hidden transition-all duration-200">
      
      {/* Header */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="p-5 flex items-center justify-between cursor-pointer bg-gradient-to-r from-amber-500/10 to-transparent hover:from-amber-500/15 select-none"
      >
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
            <EyeOff className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider">
                {item.issueType || 'Potentially One-Sided / Vague'}
              </span>
              {item.page && (
                <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  Page {item.page}
                </span>
              )}
            </div>
            <h4 className="text-base font-bold text-slate-100 mt-1">{item.title}</h4>
          </div>
        </div>

        <button className="p-2 rounded-lg text-slate-400 hover:text-white">
          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
      </div>

      {/* Expanded Details */}
      {isExpanded && (
        <div className="p-6 space-y-5 border-t border-slate-800 bg-navy-900/90 text-sm">
          
          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span>Why This Deserves Closer Review</span>
            </h5>
            <p className="text-slate-200 leading-relaxed bg-slate-800/40 p-3 rounded-xl border border-slate-800">
              {item.explanation}
            </p>
          </div>

          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <span>Potential Risk to Worker</span>
            </h5>
            <p className="text-amber-200 leading-relaxed bg-amber-500/10 p-3 rounded-xl border border-amber-500/20">
              {item.whyItMatters}
            </p>
          </div>

          <div>
            <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Suggested Clarification</span>
            </h5>
            <p className="text-emerald-300 leading-relaxed bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/30 font-medium">
              {item.recommendation}
            </p>
          </div>

          {/* Original Clause Text */}
          {item.originalText && (
            <div className="pt-2 border-t border-slate-800">
              <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5 mb-1.5">
                <FileText className="w-4 h-4 text-slate-400" />
                <span>Original Contract Text</span>
              </h5>
              <div className="p-3 rounded-xl bg-navy-950 border border-slate-800 text-xs font-mono text-slate-300 whitespace-pre-wrap leading-relaxed">
                "{item.originalText}"
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
};

export default MisleadingCard;
