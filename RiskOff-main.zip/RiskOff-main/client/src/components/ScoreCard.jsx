import React from 'react';
import { AlertTriangle, Eye, ShieldAlert, CheckCircle2, Info } from 'lucide-react';

const ScoreCard = ({ riskScore = 0, riskLevel = 'LOW RISK', transparencyScore = 100, transparencyLevel = 'HIGH TRANSPARENCY' }) => {
  // Determine Risk Color Schemes
  const getRiskColors = (score) => {
    if (score >= 76) return { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30', bar: 'bg-rose-500', badge: 'bg-rose-500/20 text-rose-300' };
    if (score >= 51) return { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', bar: 'bg-amber-500', badge: 'bg-amber-500/20 text-amber-300' };
    if (score >= 26) return { text: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/30', bar: 'bg-yellow-500', badge: 'bg-yellow-500/20 text-yellow-300' };
    return { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', bar: 'bg-emerald-500', badge: 'bg-emerald-500/20 text-emerald-300' };
  };

  // Determine Transparency Color Schemes
  const getTransparencyColors = (score) => {
    if (score >= 80) return { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', bar: 'bg-emerald-500', badge: 'bg-emerald-500/20 text-emerald-300' };
    if (score >= 55) return { text: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/30', bar: 'bg-cyan-500', badge: 'bg-cyan-500/20 text-cyan-300' };
    return { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30', bar: 'bg-rose-500', badge: 'bg-rose-500/20 text-rose-300' };
  };

  const riskColors = getRiskColors(riskScore);
  const transColors = getTransparencyColors(transparencyScore);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
      
      {/* RiskOff Risk Indicator */}
      <div className={`p-6 rounded-2xl bg-navy-900 border ${riskColors.border} shadow-xl relative overflow-hidden`}>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <ShieldAlert className={`w-5 h-5 ${riskColors.text}`} />
              <h3 className="text-sm font-semibold tracking-wider text-slate-300 uppercase">RiskOff Risk Indicator</h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">Aggregate evaluation of potential exposure & strict clauses</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${riskColors.badge}`}>
            {riskLevel}
          </span>
        </div>

        <div className="mt-6 flex items-baseline space-x-3">
          <span className={`text-5xl font-black tracking-tight ${riskColors.text}`}>{riskScore}</span>
          <span className="text-slate-500 font-medium text-lg">/ 100</span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-800 rounded-full h-3 mt-4 overflow-hidden p-0.5">
          <div
            className={`h-full rounded-full transition-all duration-700 ease-out ${riskColors.bar}`}
            style={{ width: `${Math.min(100, Math.max(5, riskScore))}%` }}
          />
        </div>

        <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
          <span>0 (Minimal Risk)</span>
          <span>50 (Moderate)</span>
          <span>100 (Critical Risk)</span>
        </div>
      </div>

      {/* Transparency Score */}
      <div className={`p-6 rounded-2xl bg-navy-900 border ${transColors.border} shadow-xl relative overflow-hidden`}>
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <Eye className={`w-5 h-5 ${transColors.text}`} />
              <h3 className="text-sm font-semibold tracking-wider text-slate-300 uppercase">Transparency Score</h3>
            </div>
            <p className="text-xs text-slate-400 mt-1">Clarity of obligations, terms, and absence of ambiguity</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${transColors.badge}`}>
            {transparencyLevel}
          </span>
        </div>

        <div className="mt-6 flex items-baseline space-x-3">
          <span className={`text-5xl font-black tracking-tight ${transColors.text}`}>{transparencyScore}</span>
          <span className="text-slate-500 font-medium text-lg">/ 100</span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-800 rounded-full h-3 mt-4 overflow-hidden p-0.5">
          <div
            className={`h-full rounded-full transition-all duration-700 ease-out ${transColors.bar}`}
            style={{ width: `${Math.min(100, Math.max(5, transparencyScore))}%` }}
          />
        </div>

        <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
          <span>0 (Vague & Ambiguous)</span>
          <span>60 (Standard)</span>
          <span>100 (Clear & Transparent)</span>
        </div>
      </div>

    </div>
  );
};

export default ScoreCard;
