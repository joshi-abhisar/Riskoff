import React, { useState } from 'react';
import { FileText, Copy, Check, ChevronDown, ChevronUp } from 'lucide-react';

const ClauseCard = ({ clause }) => {
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const handleCopy = (e) => {
    e.stopPropagation();
    navigator.clipboard.writeText(clause.originalText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-2xl bg-navy-900 border border-slate-800 hover:border-slate-700 p-5 shadow-sm transition-all duration-200">
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-start justify-between cursor-pointer select-none"
      >
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              {clause.category}
            </span>
            {clause.page && (
              <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                Page {clause.page}
              </span>
            )}
          </div>
          <h4 className="text-sm font-bold text-slate-200 mt-1">{clause.title || clause.category}</h4>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopy}
            title="Copy clause text"
            className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
          <button className="p-1.5 rounded-lg text-slate-400 hover:text-white">
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className={`mt-3 text-xs text-slate-300 font-mono bg-navy-950 p-3.5 rounded-xl border border-slate-800/80 leading-relaxed whitespace-pre-wrap ${!isExpanded ? 'line-clamp-3' : ''}`}>
        {clause.originalText}
      </div>
    </div>
  );
};

export default ClauseCard;
