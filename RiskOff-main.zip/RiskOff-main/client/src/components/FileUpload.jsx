import React, { useState, useRef } from 'react';
import { UploadCloud, File, CheckCircle, AlertCircle, Globe, ChevronDown, Sparkles } from 'lucide-react';

const LANGUAGES = [
  { code: 'en', name: 'English (Default)', native: 'English' },
  { code: 'hi', name: 'Hindi (हिंदी)', native: 'हिंदी' },
  { code: 'hinglish', name: 'Hinglish (Hindi in Latin Script)', native: 'Hinglish' },
  { code: 'bn', name: 'Bengali (বাংলা)', native: 'বাংলা' },
  { code: 'mr', name: 'Marathi (मराठी)', native: 'मराठी' },
  { code: 'ta', name: 'Tamil (தமிழ்)', native: 'தமிழ்' },
  { code: 'te', name: 'Telugu (తెలుగు)', native: 'తెలుగు' },
  { code: 'gu', name: 'Gujarati (ગુજરાતી)', native: 'ગુજરાતી' },
  { code: 'kn', name: 'Kannada (ಕನ್ನಡ)', native: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam (മലയാളം)', native: 'മലയാളം' },
  { code: 'pa', name: 'Punjabi (ਪੰਜਾਬੀ)', native: 'ਪੰਜਾਬੀ' },
];

const SAMPLE_CONTRACT_TEXT = `FREELANCE SERVICES AGREEMENT

This Agreement is entered into by and between Acme Digital Corp ("Company") and Contractor ("Service Provider").

1. SERVICES AND SCOPE OF WORK
1.1 Deliverables. The Contractor agrees to provide engineering services to the complete and absolute satisfaction of the Company as determined in its sole discretion.
1.2 Scope Modifications. The Company reserves the unilateral right to alter deliverables and assign additional tasks without additional compensation.

2. PAYMENT TERMS & DISCRETIONARY DEDUCTIONS
2.1 Payment Schedule. Invoices shall be payable on Net 90 days terms following submission and verification of deliverables.
2.2 Deductions & Offsets. The Company reserves the right to deduct from any payments or clawback fees previously paid at its sole discretion.

3. TERM AND UNILATERAL TERMINATION
3.1 Termination. The Company may terminate this Agreement immediately without prior notice and without specifying cause at any time.
3.2 Contractor Restrictions. The Contractor shall not have the right to terminate early and forfeits all unpaid compensation upon exit.

4. INTELLECTUAL PROPERTY & PERPETUAL ASSIGNMENT
4.1 Broad Assignment. The Contractor irrevocably and perpetually assigns worldwide to the Company all pre-existing, current, and future inventions, code, designs, patents, copyright, and moral rights conceived during or outside working hours.

5. UNLIMITED LIABILITY & BROAD INDEMNIFICATION
5.1 Unlimited Liability. The Contractor agrees to unlimited liability for any and all direct, indirect, consequential, or incidental damages.
5.2 Indemnity. The Contractor agrees to indemnify, defend, and hold harmless the Company from and against any and all claims, losses, damages, costs, including attorneys' fees, regardless of fault.

6. WORLDWIDE NON-COMPETE
6.1 Restrictive Covenant. The Contractor shall not directly or indirectly engage in any competing business or freelancing in the industry worldwide for a period of 2 years following termination.

7. CONFIDENTIALITY & ARBITRATION
7.1 Perpetual Secrecy. Confidentiality obligations shall survive in perpetuity, and the Contractor shall never disclose any aspect of work or use it in a professional portfolio.
7.2 Dispute Resolution. Exclusive jurisdiction and binding arbitration shall be held in Delaware, and the Contractor hereby waives all rights to trial by jury.`;

const FileUpload = ({ onStartAnalysis, isAnalyzing }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [dragActive, setDragActive] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef(null);

  const allowedTypes = ['.pdf', '.png', '.jpg', '.jpeg', '.docx', '.txt'];
  const maxSizeBytes = 10 * 1024 * 1024; // 10MB

  const validateAndSetFile = (file) => {
    setErrorMsg('');
    if (!file) return;

    const ext = '.' + file.name.split('.').pop().toLowerCase();
    if (!allowedTypes.includes(ext)) {
      setErrorMsg(`Invalid file type (${ext}). Please upload a PDF, DOCX, PNG, JPG, or TXT file.`);
      return;
    }

    if (file.size > maxSizeBytes) {
      setErrorMsg(`File exceeds 10MB limit (${(file.size / (1024 * 1024)).toFixed(2)} MB). Please select a smaller document.`);
      return;
    }

    if (file.size === 0) {
      setErrorMsg('The selected file is empty.');
      return;
    }

    setSelectedFile(file);
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0]);
    }
  };

  const handleUseSample = () => {
    setErrorMsg('');
    const sampleBlob = new Blob([SAMPLE_CONTRACT_TEXT], { type: 'text/plain' });
    const sampleFile = new window.File([sampleBlob], 'sample_freelance_contract.txt', { type: 'text/plain' });
    setSelectedFile(sampleFile);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedFile) {
      setErrorMsg('Please select a contract file or click "Load Sample Contract".');
      return;
    }
    onStartAnalysis(selectedFile, selectedLanguage);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-3xl mx-auto space-y-6">
      
      {/* Language Selection Bar */}
      <div className="p-4 rounded-2xl bg-navy-900 border border-slate-800 shadow-md">
        <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center space-x-2">
          <Globe className="w-4 h-4 text-emerald-400" />
          <span>Select Explanation Language</span>
        </label>
        <div className="relative">
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            disabled={isAnalyzing}
            className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-4 py-3 text-slate-100 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent appearance-none cursor-pointer pr-10"
          >
            {LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.name}
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-400">
            <ChevronDown className="w-4 h-4" />
          </div>
        </div>
        <p className="text-[11px] text-slate-400 mt-2">
          The original contract text will remain untouched; all summaries, risks, and recommendations will be simplified in your chosen language.
        </p>
      </div>

      {/* Drag & Drop Area */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current && fileInputRef.current.click()}
        className={`relative border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-200 ${
          dragActive
            ? 'border-emerald-400 bg-emerald-500/10 scale-[1.01]'
            : 'border-slate-700/80 bg-navy-900/60 hover:bg-navy-900 hover:border-slate-500'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.docx,.png,.jpg,.jpeg,.txt"
          onChange={handleChange}
          disabled={isAnalyzing}
          className="hidden"
        />

        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-center text-emerald-400 shadow-lg">
            <UploadCloud className="w-8 h-8" />
          </div>

          <div>
            <p className="text-base font-semibold text-slate-200">
              Drag & drop your contract here, or <span className="text-emerald-400 underline decoration-emerald-500/40 underline-offset-4">browse files</span>
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Supports PDF, DOCX, Scanned Images (PNG, JPG), or Plain Text up to 10 MB
            </p>
          </div>

          {selectedFile && (
            <div className="mt-2 inline-flex items-center space-x-2 px-4 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-sm font-medium">
              <File className="w-4 h-4 text-emerald-400" />
              <span className="truncate max-w-xs">{selectedFile.name}</span>
              <span className="text-xs text-emerald-400/70">({(selectedFile.size / 1024).toFixed(1)} KB)</span>
              <CheckCircle className="w-4 h-4 text-emerald-400 ml-1" />
            </div>
          )}
        </div>
      </div>

      {/* Quick Sample Contract Button */}
      <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/40 border border-slate-700/60 text-xs">
        <div className="flex items-center space-x-2 text-slate-300">
          <Sparkles className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>Don't have a contract file ready?</span>
        </div>
        <button
          type="button"
          onClick={handleUseSample}
          disabled={isAnalyzing}
          className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 font-semibold border border-slate-700 hover:border-emerald-500/40 transition-colors shadow-sm"
        >
          Load Sample Contract
        </button>
      </div>

      {/* Error Alert */}
      {errorMsg && (
        <div className="flex items-center space-x-3 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Action Button */}
      <button
        type="submit"
        disabled={!selectedFile || isAnalyzing}
        className={`w-full py-4 rounded-2xl font-bold text-base shadow-xl transition-all duration-200 flex items-center justify-center space-x-2 ${
          !selectedFile || isAnalyzing
            ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-navy-950 shadow-emerald-500/20 hover:scale-[1.01] active:scale-[0.99]'
        }`}
      >
        <UploadCloud className="w-5 h-5" />
        <span>{isAnalyzing ? 'Analyzing Contract...' : 'Analyze Contract Now'}</span>
      </button>

    </form>
  );
};

export default FileUpload;
