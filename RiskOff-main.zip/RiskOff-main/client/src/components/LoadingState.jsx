import React, { useEffect, useState } from 'react';
import { Loader2, CheckCircle2, ShieldCheck, FileSearch, Sparkles, Scale } from 'lucide-react';

const STEPS = [
  { label: 'Uploading contract file securely...', icon: FileSearch },
  { label: 'Extracting digital text & running OCR if needed...', icon: Sparkles },
  { label: 'Segmenting clauses (Payment, Liability, IP, Termination)...', icon: Scale },
  { label: 'Scanning for high-risk & misleading terms...', icon: ShieldCheck },
  { label: 'Calculating Risk Indicator & Transparency Score...', icon: Scale },
  { label: 'Translating & structuring localized recommendations...', icon: Sparkles },
];

const LoadingState = ({ currentStep = 0 }) => {
  const [activeStep, setActiveStep] = useState(currentStep);

  useEffect(() => {
    // Smooth progress simulation if real step isn't pushed directly
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev < STEPS.length - 1 ? prev + 1 : prev));
    }, 1800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto p-8 rounded-3xl bg-navy-900 border border-slate-800 shadow-2xl text-center my-8">
      <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 mx-auto flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/10">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>

      <h3 className="text-xl font-bold text-white mb-2">Analyzing Your Contract</h3>
      <p className="text-xs text-slate-400 mb-8">
        Running local NLP legal rules, clause classification, and transparency checks...
      </p>

      {/* Steps List */}
      <div className="space-y-4 text-left">
        {STEPS.map((step, idx) => {
          const isDone = idx < activeStep;
          const isCurrent = idx === activeStep;

          return (
            <div
              key={idx}
              className={`flex items-center space-x-3 p-3 rounded-xl border transition-all ${
                isDone
                  ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-300'
                  : isCurrent
                  ? 'bg-slate-800/80 border-slate-700 text-white ring-1 ring-emerald-500/50'
                  : 'bg-transparent border-transparent text-slate-500'
              }`}
            >
              {isDone ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              ) : isCurrent ? (
                <Loader2 className="w-5 h-5 text-emerald-400 animate-spin flex-shrink-0" />
              ) : (
                <div className="w-5 h-5 rounded-full border border-slate-700 flex-shrink-0 flex items-center justify-center text-[10px] text-slate-500">
                  {idx + 1}
                </div>
              )}
              <span className={`text-xs font-medium ${isCurrent ? 'font-semibold' : ''}`}>
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LoadingState;
