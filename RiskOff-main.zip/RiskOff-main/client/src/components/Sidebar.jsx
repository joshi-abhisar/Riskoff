import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Upload, FileText, Settings, ShieldCheck, LifeBuoy, FileCode } from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  const isActive = (path) => location.pathname === path;

  const links = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Analyze Contract', path: '/upload', icon: Upload },
    { name: 'System Diagnostics', path: '/settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-navy-900 border-r border-slate-800 flex flex-col justify-between p-4 min-h-[calc(100vh-4rem)] hidden md:flex">
      <div className="space-y-6">
        <div className="space-y-1">
          <p className="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider">Navigation</p>
          {links.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  active
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </div>

        {/* Quick Tips Box */}
        <div className="p-4 rounded-2xl bg-gradient-to-b from-slate-800/80 to-slate-800/40 border border-slate-700/60 shadow-inner">
          <div className="flex items-center space-x-2 text-emerald-400 mb-2">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Zero-Cost AI</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            100% private, offline-capable analysis. No documents leave your local infrastructure.
          </p>
        </div>
      </div>

      {/* Footer info */}
      <div className="pt-4 border-t border-slate-800 text-xs text-slate-500 space-y-1">
        <p className="font-semibold text-slate-400">RiskOff LegalTech v1.0</p>
        <p>Rule-Based & Local AI Pipeline</p>
      </div>
    </aside>
  );
};

export default Sidebar;
