import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 120000, // 2 minutes timeout for large document OCR / parsing
});

// Request interceptor to attach JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('riskoff_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle 401 unauthorized
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Clear token if expired/invalid and not already on login/register
      const path = window.location.pathname;
      if (path !== '/login' && path !== '/register' && path !== '/') {
        localStorage.removeItem('riskoff_token');
        localStorage.removeItem('riskoff_user');
      }
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
  logout: () => api.post('/auth/logout'),
};

export const contractsAPI = {
  upload: (formData) => api.post('/contracts/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
  getAll: () => api.get('/contracts'),
  getById: (id) => api.get(`/contracts/${id}`),
  delete: (id) => api.delete(`/contracts/${id}`),
};

export const analysisAPI = {
  analyze: (contractId, preferredLanguage = 'en') =>
    api.post(`/analyze/${contractId}`, { preferredLanguage }),
  getByContractId: (contractId) => api.get(`/analyze/${contractId}`),
};

export const systemAPI = {
  getHealth: () => api.get('/health'),
};

export default api;
