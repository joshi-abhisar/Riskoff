"""
ollama_service.py - Optional local LLM client using Ollama HTTP API.

Features:
- Safe connection checking with short timeouts (never hangs or crashes).
- Seamless automatic fallback to rule-based engine when Ollama is offline or model is missing.
- Zero-cost, 100% local processing.
"""

import os
import logging
import httpx
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")


async def is_ollama_available() -> dict:
    """
    Checks if Ollama server is running locally and inspects installed models.
    """
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            resp = await client.get(f"{OLLAMA_URL}/api/tags")
            if resp.status_code == 200:
                data = resp.json()
                models = [m.get("name") for m in data.get("models", [])]
                model_ready = any(OLLAMA_MODEL in m for m in models)
                return {
                    "available": True,
                    "url": OLLAMA_URL,
                    "target_model": OLLAMA_MODEL,
                    "model_ready": model_ready,
                    "installed_models": models,
                    "message": f"Ollama is running. Model '{OLLAMA_MODEL}' is {'ready' if model_ready else 'not found'}."
                }
    except Exception as e:
        logger.debug(f"Ollama connection check failed: {e}")

    return {
        "available": False,
        "url": OLLAMA_URL,
        "target_model": OLLAMA_MODEL,
        "model_ready": False,
        "installed_models": [],
        "message": "Ollama local server is not running. Using built-in rule-based AI engine."
    }


async def generate_ollama_explanation(prompt: str) -> str:
    """
    Calls local Ollama instance for text generation if available.
    """
    status = await is_ollama_available()
    if not status["available"] or not status["model_ready"]:
        return ""

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            payload = {
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False
            }
            resp = await client.post(f"{OLLAMA_URL}/api/generate", json=payload)
            if resp.status_code == 200:
                return resp.json().get("response", "").strip()
    except Exception as e:
        logger.warning(f"Ollama generation failed, fallback to rule-based: {e}")

    return ""
