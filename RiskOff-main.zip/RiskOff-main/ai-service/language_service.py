"""
language_service.py - Multi-language translation, simplification, and localized explanations.

Supports 11 languages:
- English
- Hindi (हिंदी)
- Hinglish (Hindi written in Latin script / Conversational Indian English)
- Bengali (বাংলা)
- Marathi (मराठी)
- Tamil (தமிழ்)
- Telugu (తెలుగు)
- Gujarati (ગુજરાતી)
- Kannada (ಕನ್ನಡ)
- Malayalam (മലയാളം)
- Punjabi (ਪੰਜਾਬੀ)

Zero-cost, local-first rule-based translation engine with optional Ollama enhancement.
Original contract text is strictly preserved.
"""

from typing import Dict, Any, List

# Supported languages metadata
SUPPORTED_LANGUAGES = {
    "en": {"code": "en", "name": "English", "native": "English"},
    "hi": {"code": "hi", "name": "Hindi", "native": "हिंदी"},
    "hinglish": {"code": "hinglish", "name": "Hinglish", "native": "Hinglish"},
    "bn": {"code": "bn", "name": "Bengali", "native": "বাংলা"},
    "mr": {"code": "mr", "name": "Marathi", "native": "मराठी"},
    "ta": {"code": "ta", "name": "Tamil", "native": "தமிழ்"},
    "te": {"code": "te", "name": "Telugu", "native": "తెలుగు"},
    "gu": {"code": "gu", "name": "Gujarati", "native": "ગુજરાતી"},
    "kn": {"code": "kn", "name": "Kannada", "native": "ಕನ್ನಡ"},
    "ml": {"code": "ml", "name": "Malayalam", "native": "മലയാളം"},
    "pa": {"code": "pa", "name": "Punjabi", "native": "ਪੰਜਾਬੀ"},
}

# Rich Multi-Language Phrase & Explanation Dictionaries
LOCALIZED_TERMS = {
    "Termination Without Notice": {
        "hi": {
            "title": "बिना किसी पूर्व सूचना के अनुबंध समाप्ति (Termination Without Notice)",
            "explanation": "कंपनी या दूसरा पक्ष बिना किसी पूर्व नोटिस या कारण बताए तुरंत अनुबंध समाप्त करने का अधिकार सुरक्षित रखता है।",
            "whyItMatters": "आपको बिना किसी पूर्व तैयारी या वित्तीय सुरक्षा के अचानक काम और आय से हाथ धोना पड़ सकता है।",
            "recommendation": "अनुबंध समाप्त करने के लिए कम से कम 15 से 30 दिनों के लिखित नोटिस का नियम जोड़ने का अनुरोध करें।"
        },
        "hinglish": {
            "title": "Bina kisi prior notice ke Contract Termination",
            "explanation": "Company ke paas contract ko bina kisi advance notice ya reason ke turant terminate karne ka right hai.",
            "whyItMatters": "Aapko bina kisi preparation ya financial safety ke achanak project aur income se haath dhona pad sakta hai.",
            "recommendation": "Contract termination ke liye kam se kam 15-30 days ka mutual written notice period add karne ko bolein."
        },
        "bn": {
            "title": "পূর্ব নোটিশ ছাড়া চুক্তি সমাপ্তি",
            "explanation": "কোম্পানি আপনাকে কোনো পূর্ব নোটিশ বা কারণ না দর্শিয়েই তাৎক্ষণিকভাবে চুক্তি বাতিল করার অধিকার রাখে।",
            "whyItMatters": "আপনি কোনো পূর্বপ্রস্তুতি ছাড়াই হঠাৎ কাজ এবং আয় হারাতে পারেন।",
            "recommendation": "চুক্তি বাতিলের ক্ষেত্রে কমপক্ষে ১৫-৩০ দিনের লিখিত নোটিশের অনুরোধ করুন।"
        },
        "mr": {
            "title": "कोणत्याही पूर्वसूचनेशिवाय करार रद्द करणे",
            "explanation": "कंपनीला कोणतीही पूर्वसूचना किंवा कारण न देता त्वरित करार समाप्त करण्याचा अधिकार मिळतो.",
            "whyItMatters": "कोणतीही तयारी न करता अचानक काम आणि उत्पन्न गमवावे लागू शकते.",
            "recommendation": "करार समाप्त करण्यासाठी किमान १५ ते ३० दिवसांच्या लेखी नोटीसचा नियम मागून घ्या."
        },
        "ta": {
            "title": "முன் அறிவிப்பின்றி ஒப்பந்தம் ரத்து செய்யப்படுதல்",
            "explanation": "நிறுவனம் எந்தவித முன்னறிவிப்பும் இன்றி உடனடி ஒப்பந்த ரத்து செய்யும் உரிமையை வைத்துள்ளது.",
            "whyItMatters": "திடீரென பணி மற்றும் வருமானத்தை இழக்கும் அபாயம் ஏற்படும்.",
            "recommendation": "15-30 நாட்கள் முன்னறிவிப்பு காலத்தை சேர்க்கக் கோருங்கள்."
        },
        "te": {
            "title": "ముందస్తు నోటీసు లేకుండా ఒప్పందం రద్దు",
            "explanation": "కంపెనీ ఎటువంటి ముందస్తు సమాచారం లేదా కారణం లేకుండా తక్షణమే ఒప్పందాన్ని రద్దు చేసుకునే హక్కును కలిగి ఉంది.",
            "whyItMatters": "మీరు ఎటువంటి సన్నద్ధత లేకుండా అకస్మాత్తుగా పనిని మరియు ఆదాయాన్ని కోల్పోవచ్చు.",
            "recommendation": "కనీసం 15-30 రోజుల రాతపూర్వక నోటీసు వ్యవధిని చేర్చమని అడగండి."
        },
        "gu": {
            "title": "કોઈપણ પૂર્વ સૂચના વિના કરાર રદ કરવો",
            "explanation": "કંપની કોઈ પૂર્વ નોટિસ આપ્યા વિના કરાર તાત્કાલિક સમાપ્ત કરવાનો અધિકાર ધરાવે છે.",
            "whyItMatters": "તમે અચાનક કામ અને આવક ગુમાવી શકો છો.",
            "recommendation": "ઓછામાં ઓછા 15-30 દિવસની લેખિત નોટિસની શરત ઉમેરવાની વિનંતી કરો."
        },
        "kn": {
            "title": "ಯಾವುದೇ ಮುನ್ಸೂಚನೆಯಿಲ್ಲದೆ ಒಪ್ಪಂದ ಮುಕ್ತಾಯ",
            "explanation": "ಕಂಪನಿಯು ಯಾವುದೇ ಮುನ್ಸೂಚನೆ ಇಲ್ಲದೆ ತಕ್ಷಣವೇ ಒಪ್ಪಂದವನ್ನು ರದ್ದುಗೊಳಿಸುವ ಹಕ್ಕನ್ನು ಹೊಂದಿದೆ.",
            "whyItMatters": "ಮುನ್ಸೂಚನೆಯಿಲ್ಲದೆ ಆದಾಯ ಮತ್ತು ಕೆಲಸವನ್ನು ಕಳೆದುಕೊಳ್ಳುವ ಅಪಾಯವಿದೆ.",
            "recommendation": "ಕನಿಷ್ಠ 15-30 ದಿನಗಳ ಲಿಖಿತ ನೋಟಿಸ್ ಅವಧಿಯನ್ನು ಕೋರಿ."
        },
        "ml": {
            "title": "മുൻകൂട്ടി അറിയിപ്പില്ലാതെ കരാർ റദ്ദാക്കൽ",
            "explanation": "കമ്പനിക്ക് മുൻകൂട്ടി അറിയിപ്പില്ലാതെ ഉടനടി കരാർ റദ്ദാക്കാൻ അവകാശമുണ്ട്.",
            "whyItMatters": "പെട്ടെന്ന് ജോലി നഷ്ടപ്പെടാനും വരുമാനമില്ലാതാകാനും സാധ്യതയുണ്ട്.",
            "recommendation": "15-30 ദിവസത്തെ രേഖാമൂലമുള്ള അറിയിപ്പ് കാലയളവ് ആവശ്യപ്പെടുക."
        },
        "pa": {
            "title": "ਬਿਨਾਂ ਕਿਸੇ ਅਗਾਊਂ ਨੋਟਿਸ ਦੇ ਇਕਰਾਰਨਾਮਾ ਰੱਦ ਕਰਨਾ",
            "explanation": "ਕੰਪਨੀ ਕੋਲ ਬਿਨਾਂ ਕਿਸੇ ਨੋਟਿਸ ਦੇ ਤੁਰੰਤ ਕੰਟਰੈਕਟ ਖਤਮ ਕਰਨ ਦਾ ਅਧਿਕਾਰ ਹੈ।",
            "whyItMatters": "ਤੁਸੀਂ ਅਚਾਨਕ ਬਿਨਾਂ ਕਿਸੇ ਤਿਆਰੀ ਦੇ ਕੰਮ ਅਤੇ ਆਮਦਨ ਗੁਆ ਸਕਦੇ ਹੋ।",
            "recommendation": "ਘੱਟੋ-ਘੱਟ 15-30 ਦਿਨਾਂ ਦੇ ਲਿਖਤੀ ਨੋਟਿਸ ਦੀ ਮੰਗ ਕਰੋ।"
        }
    },
    "Unlimited or Disproportionate Liability": {
        "hi": {
            "title": "असीमित या अत्यधिक वित्तीय दायित्व (Unlimited Liability)",
            "explanation": "किसी विवाद या गलती की स्थिति में आपकी वित्तीय देनदारी पर कोई अधिकतम सीमा (Cap) तय नहीं की गई है।",
            "whyItMatters": "एक साधारण गलती के कारण भी आपके ऊपर बहुत बड़ा वित्तीय भार आ सकता है।",
            "recommendation": "अपनी देनदारी को अनुबंध के तहत मिले शुल्क (Fees) तक सीमित करने की शर्त रखें।"
        },
        "hinglish": {
            "title": "Unlimited Liability aur Financial Risk",
            "explanation": "Kisi mistake ya dispute ke case mein aapke financial liability par koi limit ya cap nahi lagaya gaya hai.",
            "whyItMatters": "Ek simple issue par bhi aapke upar bahut bada financial loss/claim aa sakta hai.",
            "recommendation": "Apni liability ko maximum project fee tak limit karne ka clause add karwayein."
        },
        "bn": {
            "title": "সীমাহীন আর্থিক দায়বদ্ধতা",
            "explanation": "কোনো ভুলের ক্ষেত্রে আপনার আর্থিক ক্ষতির পরিমাণের কোনো সর্বোচ্চ সীমা রাখা হয়নি।",
            "whyItMatters": "একটি সাধারণ সমস্যা আপনার ওপর বিপুল দেনা তৈরি করতে পারে।",
            "recommendation": "আপনার দায়কে চুক্তির ফি-এর সমপরিমাণে সীমাবদ্ধ রাখার প্রস্তাব দিন।"
        },
        "mr": {
            "title": "अमर्यादित किंवा अत्यधिक आर्थिक जबाबदारी",
            "explanation": "विवादाच्या वेळी तुमच्या आर्थिक जबाबदारीवर कोणतीही मर्यादा (Cap) ठेवलेली नाही.",
            "whyItMatters": "एका छोट्या चुकीमुळेही मोठे आर्थिक नुकसान होऊ शकते.",
            "recommendation": "जबाबदारी केवळ मिळालेल्या फी पुरतीच मर्यादित ठेवा."
        },
        "ta": {
            "title": "வரம்பற்ற நிதிப் பொறுப்பு",
            "explanation": "பிழைகள் ஏற்பட்டால் உங்கள் நிதி இழப்பீட்டுக்கு உச்ச வரம்பு நிர்ணயிக்கப்படவில்லை.",
            "whyItMatters": "ஒரு சிறிய பிழையும் பெரிய நிதிச்சுமையை ஏற்படுத்தக்கூடும்.",
            "recommendation": "பொறுப்பை ஒப்பந்த கட்டண வரம்பிற்குள் கொண்டு வாருங்கள்."
        },
        "te": {
            "title": "అపరిమిత ఆర్థిక బాధ్యత",
            "explanation": "వివాదాల సమయంలో మీ ఆర్థిక బాధ్యతపై ఎటువంటి గరిష్ట పరిమితి లేదు.",
            "whyItMatters": "చిన్న పొరపాటు కూడా భారీ ఆర్థిక నష్టాన్ని కలిగిస్తుంది.",
            "recommendation": "బాధ్యతను ప్రాజెక్ట్ ఫీజుకు మాత్రమే పరిమితం చేయండి."
        },
        "gu": {
            "title": "અમર્યાદિત નાણાકીય જવાબદારી",
            "explanation": "કોઈ વિવાદના કિસ્સામાં તમારી નાણાકીય જવાબદારી પર કોઈ મર્યાદા નથી.",
            "whyItMatters": "નાની ભૂલ પણ મોટું નાણાકીય નુકસાન લાવી શકે છે.",
            "recommendation": "જવાબદારીને પ્રોજેક્ટ ફી સુધી મર્યાદિત કરવાની શરત મૂકો."
        },
        "kn": {
            "title": "ಅನಿಯಮಿತ ಆರ್ಥಿಕ ಹೊಣೆಗಾರಿಕೆ",
            "explanation": "ವಿವಾದದ ಸಂದರ್ಭದಲ್ಲಿ ನಿಮ್ಮ ಆರ್ಥಿಕ ಹೊಣೆಗಾರಿಕೆಗೆ ಯಾವುದೇ ಮಿತಿ ಇಲ್ಲ.",
            "whyItMatters": "ಸಣ್ಣ ತಪ್ಪಿಗೂ ಭಾರಿ ಆರ್ಥಿಕ ಹೊರೆಯನ್ನು ಎದುರಿಸಬೇಕಾಗಬಹುದು.",
            "recommendation": "ಹೊಣೆಗಾರಿಕೆಯನ್ನು ಯೋಜನೆಯ ಶುಲ್ಕಕ್ಕೆ ಸೀಮಿತಗೊಳಿಸಿ."
        },
        "ml": {
            "title": "പരിധിയില്ലാത്ത ബാധ്യത",
            "explanation": "തർക്കമുണ്ടായാൽ നിങ്ങളുടെ ബാധ്യതയ്ക്ക് പരമാവധി പരിധിയില്ല.",
            "whyItMatters": "ചെറിയ പിഴവിനും വലിയ നഷ്ടപരിഹാരം നൽകേണ്ടി വന്നേക്കാം.",
            "recommendation": "ബാധ്യത ലഭിച്ച പ്രതിഫലത്തിലേക്ക് പരിമിതപ്പെടുത്തുക."
        },
        "pa": {
            "title": "ਅਸੀਮਤ ਵਿੱਤੀ ਦੇਣਦਾਰੀ",
            "explanation": "ਕਿਸੇ ਵਿਵਾਦ ਸਮੇਂ ਤੁਹਾਡੀ ਵਿੱਤੀ ਦੇਣਦਾਰੀ ਦੀ ਕੋਈ ਹੱਦ ਨਹੀਂ ਰੱਖੀ ਗਈ।",
            "whyItMatters": "ਇੱਕ ਨਿੱਕੀ ਜਿਹੀ ਗਲਤੀ ਵੀ ਵੱਡਾ ਵਿੱਤੀ ਬੋਝ ਪਾ ਸਕਦੀ ਹੈ।",
            "recommendation": "ਦੇਣਦਾਰੀ ਨੂੰ ਕੰਟਰੈਕਟ ਫੀਸ ਤੱਕ ਸੀਮਤ ਕਰਨ ਦੀ ਮੰਗ ਕਰੋ।"
        }
    },
    "Broad Assignment of All Pre-existing & Moral Rights": {
        "hi": {
            "title": "सभी पूर्व-मौजूदा और बौद्धिक संपदा अधिकारों का व्यापक हस्तांतरण (IP Rights)",
            "explanation": "यह खंड न केवल इस प्रोजेक्ट के काम का, बल्कि आपके पुराने टूल्स और विचारों का मालिकाना हक भी कंपनी को दे सकता है।",
            "whyItMatters": "आप अपने स्वयं के पहले से बनाए गए टूल्स, टेम्प्लेट्स या भविष्य के पर्सनल प्रोजेक्ट्स का अधिकार खो सकते हैं।",
            "recommendation": "स्पष्ट करें कि पूरा भुगतान मिलने पर केवल इस प्रोजेक्ट के लिए बनाए गए काम का ही अधिकार दिया जाएगा।"
        },
        "hinglish": {
            "title": "Saare Pre-existing aur IP Rights ka Broad Transfer",
            "explanation": "Ye clause project ke alawa aapke purane reusable tools aur code/designs ka ownership bhi company ko transfer kar sakta hai.",
            "whyItMatters": "Aap apne reusable templates ya future side-projects ke rights kho sakte hain.",
            "recommendation": "Specify karein ki sirf full payment milne ke baad hi is specific deliverable ka ownership transfer hoga."
        },
        "bn": {
            "title": "মেধাসম্পদের অতিরিক্ত হস্তান্তর (IP Rights)",
            "explanation": "এই ধারা আপনার পূর্ববর্তী টুলস এবং সাধারণ কোড/ডিজাইনের মালিকানাও কোম্পানির কাছে দিয়ে দিতে পারে।",
            "whyItMatters": "আপনি নিজের তৈরি করা পূর্ববর্তী টেমপ্লেটগুলির ওপর নিয়ন্ত্রণ হারাতে পারেন।",
            "recommendation": "শুধুমাত্র পূর্ণ পারিশ্রমিক প্রাপ্তির পর নির্দিষ্ট কাজের স্বত্ব হস্তান্তরের নিয়ম করুন।"
        },
        "mr": {
            "title": "सर्व बौद्धिक संपदा अधिकारांचे हस्तांतरण",
            "explanation": "हा नियम तुमच्या जुन्या टूल्स आणि कोडिंगची मालकी देखील कंपनीकडे सोपवू शकतो.",
            "whyItMatters": "तुम्ही तुमच्या पुनर्वापरयोग्य टेम्प्लेट्सवरील हक्क गमावू शकता.",
            "recommendation": "पूर्ण मोबदला मिळाल्यावरच विशिष्ट कामाचे हक्क द्या."
        },
        "ta": {
            "title": "அறிவுசார் சொத்துரிமை முழுமை மாற்றம் (IP Transfer)",
            "explanation": "உங்கள் முந்தைய கருவிகள் மற்றும் யோசனைகளின் உரிமையையும் நிறுவனம் எடுத்துக்கொள்ளக்கூடும்.",
            "whyItMatters": "உங்கள் சொந்த மறுபயன்பாட்டு வார்ப்புருக்களின் உரிமையை இழக்க நேரிடும்.",
            "recommendation": "முழு கட்டணம் பெற்ற பின்னரே உரிமை மாற்றம் நிகழும் என குறிப்பிடுங்கள்."
        },
        "te": {
            "title": "మేధో సంపత్తి హక్కుల విస్తృత బదిలీ",
            "explanation": "ఈ నిబంధన మీ పాత టూల్స్ మరియు ఆలోచనల యాజమాన్యాన్ని కూడా కంపెనీకి బదిలీ చేయవచ్చు.",
            "whyItMatters": "మీ స్వంత టెంప్లేట్‌లపై హక్కులను కోల్పోయే అవకాశం ఉంది.",
            "recommendation": "పూర్తి చెల్లింపు అందిన తర్వాతే డెలివరీ చేయబడిన పని హక్కులు బదిలీ చేయాలని స్పష్టం చేయండి."
        },
        "gu": {
            "title": "તમામ બૌદ્ધિક સંપદા હકોનું ટ્રાન્સફર",
            "explanation": "આ શરત તમારા અગાઉના ટૂલ્સ અને કોડની માલિકી પણ કંપનીને આપી શકે છે.",
            "whyItMatters": "તમે તમારા પોતાના સાધનો પરનો નિયંત્રણ ગુમાવી શકો છો.",
            "recommendation": "પૂર્ણ ચુકવણી પછી જ પ્રોજેક્ટની માલિકી સોંપો."
        },
        "kn": {
            "title": "ಎಲ್ಲಾ ಬೌದ್ಧಿಕ ಆಸ್ತಿ ಹಕ್ಕುಗಳ ವರ್ಗಾವಣೆ",
            "explanation": "ಈ ಷರತ್ತು ನಿಮ್ಮ ಹಿಂದಿನ ಪರಿಕರಗಳ ಮಾಲೀಕತ್ವವನ್ನು ಸಹ ಕಂಪನಿಗೆ ವರ್ಗಾಯಿಸಬಹುದು.",
            "whyItMatters": "ನಿಮ್ಮ ಸ್ವಂತ ಟೆಂಪ್ಲೇಟ್‌ಗಳ ಹಕ್ಕುಗಳನ್ನು ನೀವು ಕಳೆದುಕೊಳ್ಳಬಹುದು.",
            "recommendation": "ಸಂಪೂರ್ಣ ಪಾವತಿಯ ನಂತರವೇ ಹಕ್ಕುಗಳನ್ನು ವರ್ಗಾಯಿಸಿ."
        },
        "ml": {
            "title": "ബൗദ്ധിക സ്വത്തവകാശ കൈമാറ്റം",
            "explanation": "നിങ്ങളുടെ മുൻകാല ഉപകരണങ്ങളുടെ ഉടമസ്ഥാവകാശവും കമ്പനിക്ക് ലഭിച്ചേക്കാം.",
            "whyItMatters": "സ്വന്തം പുനരുപയോഗ മാതൃകകളുടെ നിയന്ത്രണം നഷ്ടപ്പെടാം.",
            "recommendation": "പൂർണ്ണ പേയ്‌മെന്റ് ലഭിച്ച ശേഷം മാത്രം അവകാശം നൽകുക."
        },
        "pa": {
            "title": "ਸਾਰੇ ਬੌਧਿਕ ਸੰਪਤੀ ਹੱਕਾਂ ਦਾ ਤਬਾਦਲਾ",
            "explanation": "ਇਹ ਧਾਰਾ ਤੁਹਾਡੇ ਪੁਰਾਣੇ ਟੂਲਸ ਅਤੇ ਕੋਡ ਦੀ ਮਾਲਕੀ ਵੀ ਕੰਪਨੀ ਨੂੰ ਦੇ ਸਕਦੀ ਹੈ।",
            "whyItMatters": "ਤੁਸੀਂ ਆਪਣੇ ਪੁਰਾਣੇ ਕੰਮ ਦੇ ਹੱਕ ਗੁਆ ਸਕਦੇ ਹੋ।",
            "recommendation": "ਪੂਰੀ ਅਦਾਇਗੀ ਮਿਲਣ ਤੋਂ ਬਾਅਦ ਹੀ ਹੱਕ ਦੇਣ ਦੀ ਸ਼ਰਤ ਰੱਖੋ।"
        }
    },
    "Unclear or Extended Payment Timeline (Net 60+ / Discretionary)": {
        "hi": {
            "title": "अस्पष्ट या देर से भुगतान की शर्तें (Payment Terms)",
            "explanation": "भुगतान की समय-सीमा बहुत लंबी है (60 दिन से अधिक) या पूरी तरह से क्लाइंट की व्यक्तिपरक संतुष्टि पर निर्भर है।",
            "whyItMatters": "काम पूरा करने के बाद भी आपको अपने पैसे के लिए लंबा इंतजार या विवाद झेलना पड़ सकता है।",
            "recommendation": "मानक 15 या 30 दिनों (Net 15/30) के भीतर भुगतान और स्पष्ट अप्रूवल नियम तय करें।"
        },
        "hinglish": {
            "title": "Unclear ya Delayed Payment Timeline (Net 60+)",
            "explanation": "Payment timeline kaafi delayed hai ya client ki subjective marzi par chhod diya gaya hai.",
            "whyItMatters": "Kaam submit karne ke baad bhi payment ke liye lamba wait ya dispute face karna pad sakta hai.",
            "recommendation": "Net 15 ya Net 30 days payment timeline aur clear delivery sign-off criteria request karein."
        },
        "bn": {
            "title": "অস্পষ্ট বা বিলম্বিত অর্থপ্রদানের সময়সীমা",
            "explanation": "পেমেন্টের সময়সীমা অতিরিক্ত দীর্ঘ (৬০+ দিন) অথবা ক্লায়েন্টের সন্তুষ্টির ওপর নির্ভরশীল।",
            "whyItMatters": "কাজ শেষ করার পরও আপনি পারিশ্রমিক পেতে দীর্ঘ দেরির মুখোমুখি হতে পারেন।",
            "recommendation": "১৫-৩০ দিনের মধ্যে পেমেন্টের লিখিত নিশ্চয়তা নিন।"
        },
        "mr": {
            "title": "अस्पष्ट किंवा उशीरा देयकांच्या अटी",
            "explanation": "पेमेंटची मुदत खूप लांब आहे (६०+ दिवस) किंवा क्लायंटच्या मर्जीवर अवलंबून आहे.",
            "whyItMatters": "काम पूर्ण झाल्यानंतरही पैशांसाठी दीर्घकाळ वाट पाहावी लागू शकते.",
            "recommendation": "१५ ते ३० दिवसांत पेमेंटची स्पष्ट अट ठेवा."
        },
        "ta": {
            "title": "தெளிவற்ற அல்லது தாமதமான கட்டண விதிமுறைகள்",
            "explanation": "பணம் செலுத்தும் காலம் மிக நீண்டதாக உள்ளது (60+ நாட்கள்) அல்லது கிளையண்டின் விருப்பத்தை சார்ந்துள்ளது.",
            "whyItMatters": "பணி முடிந்த பின்னரும் கட்டணம் பெற நீண்ட காலம் காத்திருக்க நேரிடும்.",
            "recommendation": "15 அல்லது 30 நாட்களுக்குள் கட்டணம் செலுத்த கோருங்கள்."
        },
        "te": {
            "title": "అస్పష్టమైన లేదా ఆలస్య చెల్లింపు నిబంధనలు",
            "explanation": "చెల్లింపు గడువు చాలా ఆలస్యంగా ఉంది (60+ రోజులు) లేదా క్లయింట్ యొక్క నిర్ణయంపై ఆధారపడి ఉంటుంది.",
            "whyItMatters": "పని పూర్తయిన తర్వాత కూడా డబ్బుల కోసం ఎక్కువ కాలం వేచి ఉండాల్సి వస్తుంది.",
            "recommendation": "15 నుండి 30 రోజులలోపు చెల్లింపు జరగాలని నిర్ణయించండి."
        },
        "gu": {
            "title": "અસ્પષ્ટ અથવા વિલંબિત ચુકવણીની શરતો",
            "explanation": "ચુકવણીની સમયમર્યાદા બહુ લાંબી છે અથવા ક્લાયન્ટની મરજી પર નિર્ભર છે.",
            "whyItMatters": "કામ પૂર્ણ કર્યા પછી પણ નાણાં માટે લાંબો સમય રાહ જોવી પડી શકે છે.",
            "recommendation": "15-30 દિવસમાં ચુકવણી કરવાની સ્પષ્ટ શરત રાખો."
        },
        "kn": {
            "title": "ಅಸ್ಪಷ್ಟ ಅಥವಾ ವಿಳಂಬಿತ ಪಾವತಿ ನಿಯಮಗಳು",
            "explanation": "ಪಾವತಿ ಅವಧಿಯು ತುಂಬಾ ದೀರ್ಘವಾಗಿದೆ ಅಥವಾ ಕ್ಲೈಂಟ್ ಇಚ್ಛೆಯ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿದೆ.",
            "whyItMatters": "ಕೆಲಸ ಮುಗಿದ ನಂತರವೂ ಹಣಕ್ಕಾಗಿ ಕಾಯಬೇಕಾಗಬಹುದು.",
            "recommendation": "15-30 ದಿನಗಳಲ್ಲಿ ಪಾವತಿ ಮಾಡಬೇಕೆಂದು ಷರತ್ತು ವಿಧಿಸಿ."
        },
        "ml": {
            "title": "അവ്യക്തമായ പേയ്‌മെന്റ് നിബന്ധനകൾ",
            "explanation": "പേയ്‌മെന്റ് ലഭിക്കാൻ വളരെ കാലതാമസം ഉണ്ടാകാം (60+ ദിവസം).",
            "whyItMatters": "ജോലി കഴിഞ്ഞാലും പ്രതിഫലത്തിനായി ദീർഘകാലം കാത്തിരിക്കേണ്ടി വരും.",
            "recommendation": "15-30 ദിവസത്തിനുള്ളിൽ പേയ്‌മെന്റ് ഉറപ്പാക്കുക."
        },
        "pa": {
            "title": "ਅਸਪਸ਼ਟ ਜਾਂ ਦੇਰੀ ਨਾਲ ਭੁਗਤਾਨ ਦੀਆਂ ਸ਼ਰਤਾਂ",
            "explanation": "ਭੁਗਤਾਨ ਦਾ ਸਮਾਂ ਬਹੁਤ ਲੰਬਾ ਹੈ ਜਾਂ ਕਲਾਇੰਟ ਦੀ ਮਰਜ਼ੀ 'ਤੇ ਛੱਡਿਆ ਗਿਆ ਹੈ।",
            "whyItMatters": "ਕੰਮ ਤੋਂ ਬਾਅਦ ਵੀ ਪੈਸਿਆਂ ਲਈ ਲੰਬਾ ਇੰਤਜ਼ਾਰ ਕਰਨਾ ਪੈ ਸਕਦਾ ਹੈ।",
            "recommendation": "15-30 ਦਿਨਾਂ ਦੇ ਅੰਦਰ ਭੁਗਤਾਨ ਦੀ ਸ਼ਰਤ ਰੱਖੋ।"
        }
    },
    "Overly Restrictive Non-Compete Clause": {
        "hi": {
            "title": "अत्यधिक प्रतिबंधात्मक गैर-प्रतिस्पर्धा खंड (Non-Compete)",
            "explanation": "यह अनुबंध आपको अनुबंध समाप्त होने के बाद भी अपने क्षेत्र या अन्य क्लाइंट्स के साथ काम करने से रोकता है।",
            "whyItMatters": "यह आपकी भविष्य की कमाई और करियर की स्वतंत्रता को गंभीर रूप से सीमित कर सकता है।",
            "recommendation": "फ्रीलांसर्स के लिए गैर-प्रतिस्पर्धा खंड हटाने या इसे केवल प्रत्यक्ष क्लाइंट्स तक सीमित करने की मांग करें।"
        },
        "hinglish": {
            "title": "Strict Non-Compete Clause",
            "explanation": "Ye clause contract khatam hone ke baad bhi aapko doosre clients ya similar projects par kaam karne se rokta hai.",
            "whyItMatters": "Ye aapke future freelance work aur career growth ko restrict kar sakta hai.",
            "recommendation": "Non-compete clause ko remove karwayein ya sirf active client solicitation tak limit karein."
        }
    },
    "Broad or Uncapped Indemnification": {
        "hi": {
            "title": "व्यापक या असीमित क्षतिपूर्ति (Indemnity Clause)",
            "explanation": "आपको किसी भी कानूनी विवाद, दावे या वकील की फीस का पूरा भुगतान करने के लिए बाध्य किया जा रहा है।",
            "whyItMatters": "उन समस्याओं के लिए भी आप पर भारी कानूनी खर्च आ सकता है जो सीधे आपके नियंत्रण में नहीं थीं।",
            "recommendation": "क्षतिपूर्ति को केवल अपनी प्रत्यक्ष लापरवाही या जानबूझकर की गई गलती तक सीमित रखें।"
        },
        "hinglish": {
            "title": "Broad Indemnification aur Legal Costs",
            "explanation": "Aapko company ke saare legal costs, dispute claims aur attorneys fees pay karne ke liye liable banaya gaya hai.",
            "whyItMatters": "Aapke control se bahar ke issues ke liye bhi expensive legal costs aap par aa sakti hain.",
            "recommendation": "Indemnity ko sirf proven direct gross negligence tak limit karne ka provision rakhein."
        }
    }
}


def localize_risk_item(risk: Dict[str, Any], lang_code: str) -> Dict[str, Any]:
    """
    Translates/simplifies a risk item to the requested language while preserving originalText.
    """
    lang = lang_code.lower()
    if lang in ["en", "english"]:
        return risk

    title = risk.get("title", "")
    localized = LOCALIZED_TERMS.get(title, {}).get(lang)

    res = dict(risk)
    if localized:
        res["title"] = localized.get("title", risk["title"])
        res["explanation"] = localized.get("explanation", risk["explanation"])
        res["whyItMatters"] = localized.get("whyItMatters", risk["whyItMatters"])
        res["recommendation"] = localized.get("recommendation", risk["recommendation"])
    else:
        # Fallback to smart prefixing if language dictionary entry is generic
        native_lang = SUPPORTED_LANGUAGES.get(lang, {}).get("name", lang)
        if lang == "hi":
            res["explanation"] = f"[{native_lang} व्याख्या] " + risk["explanation"]
            res["whyItMatters"] = "[यह क्यों महत्वपूर्ण है] " + risk["whyItMatters"]
            res["recommendation"] = "[सुझाव / स्पष्टीकरण] " + risk["recommendation"]
        elif lang == "hinglish":
            res["explanation"] = "[Hinglish Explanation] " + risk["explanation"]
            res["whyItMatters"] = "[Yeh Kyun Important Hai] " + risk["whyItMatters"]
            res["recommendation"] = "[Action Recommendation] " + risk["recommendation"]
        elif lang == "bn":
            res["explanation"] = f"[{native_lang} বিবরণ] " + risk["explanation"]
            res["whyItMatters"] = "[কেন এটি গুরুত্বপূর্ণ] " + risk["whyItMatters"]
            res["recommendation"] = "[সুপারিশ] " + risk["recommendation"]
        elif lang == "mr":
            res["explanation"] = f"[{native_lang} स्पष्टीकरण] " + risk["explanation"]
            res["whyItMatters"] = "[हे का महत्त्वाचे आहे] " + risk["whyItMatters"]
            res["recommendation"] = "[शिफारस] " + risk["recommendation"]
        elif lang == "ta":
            res["explanation"] = f"[{native_lang} விளக்கம்] " + risk["explanation"]
            res["whyItMatters"] = "[இது ஏன் முக்கியம்] " + risk["whyItMatters"]
            res["recommendation"] = "[பரிந்துரை] " + risk["recommendation"]
        elif lang == "te":
            res["explanation"] = f"[{native_lang} వివరణ] " + risk["explanation"]
            res["whyItMatters"] = "[ఇది ఎందుకు ముఖ్యం] " + risk["whyItMatters"]
            res["recommendation"] = "[సిఫార్సు] " + risk["recommendation"]
        elif lang == "gu":
            res["explanation"] = f"[{native_lang} સમજૂતી] " + risk["explanation"]
            res["whyItMatters"] = "[આ શા માટે મહત્વનું છે] " + risk["whyItMatters"]
            res["recommendation"] = "[ભલામણ] " + risk["recommendation"]
        elif lang == "kn":
            res["explanation"] = f"[{native_lang} ವಿವರಣೆ] " + risk["explanation"]
            res["whyItMatters"] = "[ಇದು ಏಕೆ ಮುಖ್ಯ] " + risk["whyItMatters"]
            res["recommendation"] = "[ಶಿಫಾರಸು] " + risk["recommendation"]
        elif lang == "ml":
            res["explanation"] = f"[{native_lang} വിശദീകരണം] " + risk["explanation"]
            res["whyItMatters"] = "[ഇത് എന്തുകൊണ്ട് പ്രധാനമാണ്] " + risk["whyItMatters"]
            res["recommendation"] = "[ശുപാർശ] " + risk["recommendation"]
        elif lang == "pa":
            res["explanation"] = f"[{native_lang} ਵਿਆਖਿਆ] " + risk["explanation"]
            res["whyItMatters"] = "[ਇਹ ਕਿਉਂ ਮਹੱਤਵਪੂਰਨ ਹੈ] " + risk["whyItMatters"]
            res["recommendation"] = "[ਸਿਫ਼ਾਰਸ਼] " + risk["recommendation"]

    return res


def generate_localized_summary(
    doc_type: str,
    clause_count: int,
    risk_count: int,
    misleading_count: int,
    risk_score: int,
    lang_code: str
) -> Dict[str, Any]:
    """
    Generates a structured executive summary and key takeaways in the requested language.
    """
    lang = lang_code.lower()

    if lang == "hi":
        summary_text = (
            f"यह अनुबंध एक सेवा/व्यावसायिक समझौता है जिसमें कुल {clause_count} मुख्य खंड पाए गए हैं। "
            f"विश्लेषण के अनुसार इसमें {risk_count} संभावित जोखिम भरे बिंदु और {misleading_count} ऐसे खंड मिले हैं "
            f"जिन पर हस्ताक्षर करने से पहले स्पष्टीकरण की आवश्यकता है। समग्र जोखिम सूचकांक {risk_score}/100 है।"
        )
        takeaways = [
            "अनुबंध समाप्ति और नोटिस अवधि की शर्तों की सावधानीपूर्वक समीक्षा करें।",
            "बौद्धिक संपदा (IP Rights) केवल पूर्ण भुगतान के बाद ही ट्रांसफर करने का नियम जोड़ें।",
            "भुगतान की समय-सीमा (Net 15/30) और काम अप्रूवल के स्पष्ट नियम तय करें।",
            "असीमित देनदारी (Unlimited Liability) को प्रोजेक्ट फीस तक सीमित करने की मांग करें।"
        ]
    elif lang == "hinglish":
        summary_text = (
            f"Yeh contract ek professional service agreement hai jismein total {clause_count} clauses detect hue hain. "
            f"RiskOff analysis ke according isme {risk_count} high-risk areas aur {misleading_count} potentially misleading terms hain "
            f"jinko sign karne se pehle clarify karna zaroori hai. Overall Risk Score: {risk_score}/100."
        )
        takeaways = [
            "Contract termination aur notice period terms ko dhyan se check karein.",
            "Intellectual Property (IP) transfer ko full payment milne ke baad hi finalize karein.",
            "Payment timeline (Net 15 ya 30 days) aur objective approval criteria set karein.",
            "Unlimited liability ko project fee tak limit karwane ki demand karein."
        ]
    elif lang == "bn":
        summary_text = (
            f"এই চুক্তিটিতে মোট {clause_count}টি ধারা চিহ্নিত করা হয়েছে। "
            f"বিশ্লেষণ অনুযায়ী {risk_count}টি সম্ভাব্য ঝুঁকিপূর্ণ এবং {misleading_count}টি অস্পষ্ট ধারা রয়েছে। "
            f"সামগ্রিক ঝুঁকির সূচক: {risk_score}/১০০।"
        )
        takeaways = [
            "চুক্তি সমাপ্তি এবং নোটিশের শর্তাবলী ভালোভাবে পরীক্ষা করুন।",
            "সম্পূর্ণ অর্থ প্রদানের পরেই কেবল কাজের স্বত্ব হস্তান্তর করুন।",
            "পেমেন্টের সময়সীমা এবং অনুমোদনের নিয়ম স্পষ্ট করুন।"
        ]
    elif lang == "mr":
        summary_text = (
            f"या करारामध्ये एकूण {clause_count} मुख्य कलमे आढळली आहेत. "
            f"यामध्ये {risk_count} संभाव्य जोखीम आणि {misleading_count} अस्पष्ट कलमे आढळली आहेत. "
            f"एकूण जोखीम निर्देशांक: {risk_score}/100."
        )
        takeaways = [
            "करार रद्द करण्याच्या आणि नोटीस कालावधीच्या अटी तपासा.",
            "पूर्ण मोबदला मिळाल्यावरच बौद्धिक संपदा हस्तांतरित करा.",
            "देयकांची मुदत (Payment timeline) निश्चित करा."
        ]
    elif lang == "ta":
        summary_text = (
            f"இந்த ஒப்பந்தத்தில் {clause_count} முக்கிய பிரிவுகள் கண்டறியப்பட்டுள்ளன. "
            f"இதில் {risk_count} சாத்தியமான அபாயங்கள் மற்றும் {misleading_count} தெளிவற்ற பிரிவுகள் உள்ளன. "
            f"ஒட்டுமொத்த அபாயக் குறியீடு: {risk_score}/100."
        )
        takeaways = [
            "ஒப்பந்த ரத்து மற்றும் முன்னறிவிப்பு விதிகளை கவனியுங்கள்.",
            "முழு கட்டணம் செலுத்திய பிறகே அறிவுசார் சொத்துரிமையை வழங்கவும்.",
            "பணம் செலுத்தும் காலக்கெடுவை தெளிவுபடுத்தவும்."
        ]
    elif lang == "te":
        summary_text = (
            f"ఈ ఒప్పందంలో మొత్తం {clause_count} నిబంధనలు గుర్తించబడ్డాయి. "
            f"ఇందులో {risk_count} ప్రమాదకర మరియు {misleading_count} స్పష్టత లేని నిబంధనలు ఉన్నాయి. "
            f"మొత్తం రిస్క్ స్కోరు: {risk_score}/100."
        )
        takeaways = [
            "ముందస్తు నోటీసు నిబంధనలను స్పష్టంగా పరిశీలించండి.",
            "పూర్తి చెల్లింపు అందిన తర్వాతే మేధో సంపత్తిని బదిలీ చేయండి.",
            "చెల్లింపుల కాలపరిమితిని నిర్ణయించండి."
        ]
    elif lang == "gu":
        summary_text = (
            f"આ કરારમાં કુલ {clause_count} કલમો મળેલ છે. "
            f"તેમાં {risk_count} જોખમી અને {misleading_count} અસ્પષ્ટ શરતો સામેલ છે. "
            f"કુલ રિસ્ક સ્કોર: {risk_score}/100."
        )
        takeaways = [
            "કરાર રદ કરવાની શરતો અને નોટિસ પિરિયડ ચકાસો.",
            "સંપૂર્ણ ચૂકવણી પછી જ IP હકો ટ્રાન્સફર કરો.",
            "ચૂકવણીની સમયમર્યાદા સ્પષ્ટ કરો."
        ]
    elif lang == "kn":
        summary_text = (
            f"ಈ ಒಪ್ಪಂದದಲ್ಲಿ ಒಟ್ಟು {clause_count} ಷರತ್ತುಗಳನ್ನು ಗುರುತಿಸಲಾಗಿದೆ. "
            f"ಇದರಲ್ಲಿ {risk_count} ಅಪಾಯಕಾರಿ ಮತ್ತು {misleading_count} ಅಸ್ಪಷ್ಟ ಷರತ್ತುಗಳಿವೆ. "
            f"ಒಟ್ಟಾರೆ ರಿಸ್ಕ್ ಸ್ಕೋರ್: {risk_score}/100."
        )
        takeaways = [
            "ಮುನ್ಸೂಚನೆ ಅವಧಿ ಮತ್ತು ಒಪ್ಪಂದ ಮುಕ್ತಾಯದ ನಿಯಮಗಳನ್ನು ಪರಿಶೀಲಿಸಿ.",
            "ಸಂಪೂರ್ಣ ಪಾವತಿಯ ನಂತರವೇ IP ಹಕ್ಕುಗಳನ್ನು ವರ್ಗಾಯಿಸಿ.",
            "ಪಾವತಿ ದಿನಾಂಕಗಳನ್ನು ಸ್ಪಷ್ಟಪಡಿಸಿ."
        ]
    elif lang == "ml":
        summary_text = (
            f"ഈ കരാറിൽ ആകെ {clause_count} പ്രധാന നിബന്ധനകൾ കണ്ടെത്തി. "
            f"ഇതിൽ {risk_count} ഉയർന്ന റിസ്കും {misleading_count} അവ്യക്തമായ നിബന്ധനകളും ഉണ്ട്. "
            f"ആകെ റിസ്ക് സ്കോർ: {risk_score}/100."
        )
        takeaways = [
            "നോട്ടീസ് പിരീഡ് നിബന്ധനകൾ ശ്രദ്ധാപൂർവ്വം വായിക്കുക.",
            "മുഴുവൻ പ്രതിഫലവും ലഭിച്ച ശേഷം മാത്രം അവകാശങ്ങൾ കൈമാറുക.",
            "പേയ്‌മെന്റ് സമയപരിധി വ്യക്തമാക്കുക."
        ]
    elif lang == "pa":
        summary_text = (
            f"ਇਸ ਇਕਰਾਰਨਾਮੇ ਵਿੱਚ ਕੁੱਲ {clause_count} ਧਾਰਾਵਾਂ ਮਿਲੀਆਂ ਹਨ। "
            f"ਇਸ ਵਿੱਚ {risk_count} ਜੋਖਮ ਭਰੇ ਅਤੇ {misleading_count} ਅਸਪਸ਼ਟ ਨੁਕਤੇ ਹਨ। "
            f"ਕੁੱਲ ਜੋਖਮ ਸਕੋਰ: {risk_score}/100."
        )
        takeaways = [
            "ਕੰਟਰੈਕਟ ਸਮਾਪਤੀ ਅਤੇ ਨੋਟਿਸ ਪੀਰੀਅਡ ਦੀਆਂ ਸ਼ਰਤਾਂ ਧਿਆਨ ਨਾਲ ਦੇਖੋ।",
            "ਪੂਰੀ ਅਦਾਇਗੀ ਤੋਂ ਬਾਅਦ ਹੀ IP ਹੱਕ ਟ੍ਰਾਂਸਫਰ ਕਰੋ।",
            "ਭੁਗਤਾਨ ਦੀ ਸਮਾਂ-ਸੀਮਾ ਸਪੱਸ਼ਟ ਕਰੋ।"
        ]
    else:
        # Default English
        summary_text = (
            f"This contract is a professional services agreement containing {clause_count} analyzed clauses. "
            f"The RiskOff engine detected {risk_count} high-risk provisions and {misleading_count} potentially misleading terms "
            f"that warrant closer review and clarification before signing. Overall Risk Score: {risk_score}/100."
        )
        takeaways = [
            "Verify notice period requirements and termination for convenience clauses.",
            "Ensure Intellectual Property transfer is contingent upon receipt of full payment.",
            "Specify objective deliverable acceptance criteria and Net 15/30 payment milestones.",
            "Cap total liability to direct damages and fees received under the contract."
        ]

    return {
        "summaryText": summary_text,
        "keyTakeaways": takeaways
    }
