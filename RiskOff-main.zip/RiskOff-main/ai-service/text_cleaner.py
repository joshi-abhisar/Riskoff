"""
text_cleaner.py - Cleans and normalizes contract text for NLP processing.

Cleans:
- Excessive whitespace and empty lines
- Broken line breaks within sentences
- OCR noise artifacts
- Standard page headers / footers / page numbering
Preserves meaningful punctuation and legal structure.
"""

import re


def clean_text(text: str) -> str:
    """
    Cleans raw extracted text from PDF or OCR without destroying contract semantics.
    """
    if not text:
        return ""

    # Replace carriage returns
    cleaned = text.replace("\r\n", "\n").replace("\r", "\n")

    # Remove standard page number patterns like "Page 1 of 5", "--- Page 1 ---", "[Page 2]"
    cleaned = re.sub(r'(?i)\bpage\s+\d+\s+(of\s+\d+|/\s*\d+)', '', cleaned)
    cleaned = re.sub(r'---\s*Page\s*\d+\s*---', '', cleaned)
    cleaned = re.sub(r'\[\s*Page\s*\d+\s*\]', '', cleaned)
    cleaned = re.sub(r'(?m)^\s*\d+\s*/\s*\d+\s*$', '', cleaned)
    cleaned = re.sub(r'(?m)^\s*-\s*\d+\s*-\s*$', '', cleaned)

    # Remove common OCR artifacts (e.g. repeated stray symbols like ~~~ or ||| or ___)
    cleaned = re.sub(r'[~|]{3,}', '', cleaned)
    cleaned = re.sub(r'_{4,}', '____', cleaned)  # Normalize signature underline placeholders

    # Fix broken hyphenated words at line breaks (e.g., "agree-\nment" -> "agreement")
    cleaned = re.sub(r'(\b\w+)-\n(\w+\b)', r'\1\2', cleaned)

    # Join broken lines within a sentence (line ending in a lowercase char or comma followed by newline and lowercase)
    cleaned = re.sub(r'([a-z,;])\n([a-z])', r'\1 \2', cleaned)

    # Replace 3 or more consecutive newlines with two newlines
    cleaned = re.sub(r'\n{3,}', '\n\n', cleaned)

    # Replace multiple horizontal spaces/tabs with a single space
    cleaned = re.sub(r'[^\S\n]+', ' ', cleaned)

    # Clean leading/trailing spaces per line
    lines = [line.strip() for line in cleaned.split('\n')]
    cleaned = '\n'.join(lines).strip()

    return cleaned


def split_into_paragraphs(text: str) -> list[str]:
    """
    Splits cleaned text into logical paragraphs or clause chunks.
    """
    if not text:
        return []
    
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    return paragraphs
