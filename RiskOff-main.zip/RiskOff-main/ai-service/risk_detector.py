"""
risk_detector.py - Detects high-risk, one-sided, and potentially misleading clauses in contracts.

Uses a transparent rule-based legal-tech heuristic engine.
Enforces safe legal language (avoids claims of illegality/fraud).
"""

import re
from typing import List, Dict, Any, Tuple

# Risk Rules Definition: category, severity (LOW/MEDIUM/HIGH/CRITICAL), score (1-100), patterns, explanation, why_it_matters, recommendation
RISK_RULES = [
    {
        "id": "unilateral_term_no_notice",
        "category": "Termination",
        "title": "Termination Without Notice",
        "severity": "CRITICAL",
        "score": 90,
        "patterns": [
            r"(?i)\b(terminate\s+(immediately|without\s+(prior\s+)?notice|at\s+any\s+time\s+without\s+cause|at\s+sole\s+discretion))\b",
            r"(?i)\b(company\s+may\s+terminate\s+at\s+will|immediate\s+effect\s+without\s+notice)\b"
        ],
        "explanation": "The counterparty reserves the right to terminate the contract immediately without giving you prior notice or specifying cause.",
        "whyItMatters": "You could suddenly lose your expected income or project with zero transition time or financial buffer.",
        "recommendation": "Request a mutual written notice period (e.g., 14 or 30 days) for all termination for convenience."
    },
    {
        "id": "unilateral_term_one_sided",
        "category": "Termination",
        "title": "One-Sided Termination Rights",
        "severity": "HIGH",
        "score": 75,
        "patterns": [
            r"(?i)\b(company\s+(may|reserves\s+the\s+right\s+to)\s+terminate.*?(worker|contractor|you)\s+may\s+not)\b",
            r"(?i)\b(client\s+may\s+terminate\s+for\s+convenience.*?(contractor|worker)\s+shall\s+not\s+have\s+the\s+right)\b"
        ],
        "explanation": "The contract allows the client to terminate at will, but restricts or denies your right to terminate if conditions become unfavorable.",
        "whyItMatters": "This locks you into the agreement while allowing the other party to exit whenever it suits them.",
        "recommendation": "Negotiate balanced, bilateral termination terms allowing either party to exit with standard written notice."
    },
    {
        "id": "delayed_unclear_payment",
        "category": "Payment",
        "title": "Unclear or Extended Payment Timeline (Net 60+ / Discretionary)",
        "severity": "HIGH",
        "score": 70,
        "patterns": [
            r"(?i)\b(net\s+(60|90|120)\s+days|paid\s+when\s+paid|pay\s+when\s+paid|paid\s+if\s+paid)\b",
            r"(?i)\b(payment\s+at\s+the\s+(sole\s+)?discretion\s+of|upon\s+satisfaction\s+as\s+determined\s+solely\s+by)\b"
        ],
        "explanation": "Payment timeline is unusually delayed (e.g. Net 60+) or contingent on third-party settlement / subjective client satisfaction.",
        "whyItMatters": "You may deliver work but face long delays or disputes before receiving your earned compensation.",
        "recommendation": "Request standard Net 15 or Net 30 payment terms and clear, objective milestone approval criteria."
    },
    {
        "id": "unlimited_liability",
        "category": "Liability",
        "title": "Unlimited or Disproportionate Liability",
        "severity": "CRITICAL",
        "score": 95,
        "patterns": [
            r"(?i)\b(unlimited\s+liability|shall\s+be\s+liable\s+for\s+all\s+damages|no\s+cap\s+on\s+liability|unlimited\s+damages)\b",
            r"(?i)\b(liable\s+for\s+(indirect|consequential|incidental|punitive|special)\s+damages)\b"
        ],
        "explanation": "The contract does not place any monetary cap on your financial liability in the event of a dispute or error.",
        "whyItMatters": "A single operational issue or lawsuit could expose your personal finances to unbounded financial claims.",
        "recommendation": "Include a standard liability cap limited to fees paid under the contract during the preceding 6 to 12 months, and exclude indirect/consequential damages."
    },
    {
        "id": "broad_indemnity",
        "category": "Indemnity",
        "title": "Broad or Uncapped Indemnification",
        "severity": "HIGH",
        "score": 80,
        "patterns": [
            r"(?i)\b(indemnify,?\s+defend\s+and\s+hold\s+harmless\s+from\s+and\s+against\s+any\s+and\s+all\s+claims|all\s+losses,?\s+damages,?\s+costs,?\s+including\s+attorneys['’]?\s+fees)\b",
            r"(?i)\b(indemnify\s+against\s+any\s+negligence|regardless\s+of\s+fault)\b"
        ],
        "explanation": "You are required to defend and pay all legal costs, claims, and damages for the counterparty under very broad conditions.",
        "whyItMatters": "You could be burdened with expensive legal defense costs even for claims beyond your direct control.",
        "recommendation": "Limit indemnification solely to direct damages resulting from your proven gross negligence, willful misconduct, or direct IP infringement."
    },
    {
        "id": "broad_ip_transfer_preexisting",
        "category": "Intellectual Property",
        "title": "Broad Assignment of All Pre-existing & Moral Rights",
        "severity": "HIGH",
        "score": 80,
        "patterns": [
            r"(?i)\b(assigns\s+all\s+(prior|pre-existing|future|any\s+and\s+all)\s+inventions|waives\s+all\s+moral\s+rights|irrevocably\s+and\s+perpetually\s+assigns\s+worldwide)\b",
            r"(?i)\b(all\s+inventions\s+conceived\s+during\s+or\s+outside\s+working\s+hours|whether\s+related\s+or\s+unrelated\s+to\s+the\s+services)\b"
        ],
        "explanation": "The agreement transfers ownership not only of deliverables created under the project, but potentially your pre-existing tools, background IP, or future unrelated ideas.",
        "whyItMatters": "You might lose ownership rights to your own reusable templates, libraries, or side projects.",
        "recommendation": "Specify that only newly created client deliverables are transferred upon full payment, while retaining background IP and standard tools."
    },
    {
        "id": "unreasonable_non_compete",
        "category": "Non-compete",
        "title": "Overly Restrictive Non-Compete Clause",
        "severity": "HIGH",
        "score": 85,
        "patterns": [
            r"(?i)\b(shall\s+not\s+(directly\s+or\s+indirectly\s+)?engage\s+in\s+any\s+competing\s+business|non-compete\s+for\s+a\s+period\s+of\s+\d+\s+(years?|months?))\b",
            r"(?i)\b(restricted\s+from\s+working\s+with\s+any\s+competitor|worldwide\s+non-compete)\b"
        ],
        "explanation": "Restricts your ability to work for other clients, industry competitors, or in your field during or after the contract.",
        "whyItMatters": "This can severely restrict your future freelance earnings and career mobility.",
        "recommendation": "Seek removal of non-compete clauses for independent contractors, or limit it strictly to direct solicitation of active clients during the project."
    },
    {
        "id": "strict_exclusivity",
        "category": "Exclusivity",
        "title": "Strict Full-Time Exclusivity for Contractor",
        "severity": "MEDIUM",
        "score": 60,
        "patterns": [
            r"(?i)\b(exclusive\s+basis|shall\s+not\s+perform\s+services\s+for\s+any\s+other\s+person\s+or\s+entity|full-time\s+devotion\s+of\s+time)\b"
        ],
        "explanation": "Prohibits you from taking on other freelance work, projects, or clients while under this agreement.",
        "whyItMatters": "As an independent contractor or freelancer, exclusivity restricts your income diversification without employee benefits.",
        "recommendation": "Clarify that you operate as an independent contractor free to perform services for other non-conflicting clients."
    },
    {
        "id": "unilateral_modifications",
        "category": "Contract Changes",
        "title": "Unilateral Contract Changes / Scope Creep",
        "severity": "HIGH",
        "score": 75,
        "patterns": [
            r"(?i)\b(company\s+may\s+modify\s+the\s+terms\s+at\s+any\s+time\s+without\s+notice|reserves\s+the\s+right\s+to\s+alter\s+fees\s+or\s+duties\s+unilaterally)\b",
            r"(?i)\b(contractor\s+shall\s+perform\s+any\s+additional\s+tasks\s+without\s+additional\s+compensation)\b"
        ],
        "explanation": "The counterparty can change project scope, deliverables, or compensation terms without your mutual written agreement.",
        "whyItMatters": "Could lead to unpaid scope creep and changes to your obligations without your consent.",
        "recommendation": "Require that all changes in scope, pricing, or terms must be in writing and signed by both parties."
    },
    {
        "id": "automatic_renewal_trap",
        "category": "Renewal",
        "title": "Automatic Renewal With Short Opt-Out Window",
        "severity": "MEDIUM",
        "score": 55,
        "patterns": [
            r"(?i)\b(automatically\s+renew\s+for\s+successive\s+periods|auto-renew\s+unless\s+written\s+notice\s+is\s+given\s+at\s+least\s+\d+\s+days\s+prior)\b"
        ],
        "explanation": "The contract automatically locks you into another term unless you cancel within a specific, rigid time window.",
        "whyItMatters": "You might get unintentionally locked into recurring obligations or rates for another full term.",
        "recommendation": "Set calendar reminders for notice deadlines or request that renewal requires affirmative mutual consent."
    },
    {
        "id": "excessive_liquidated_damages",
        "category": "Penalties",
        "title": "Disproportionate Penalty / Liquidated Damages",
        "severity": "HIGH",
        "score": 80,
        "patterns": [
            r"(?i)\b(penalty\s+of\s+[\$£€₹\d]+|liquidated\s+damages\s+in\s+the\s+amount\s+of|forfeit\s+all\s+prior\s+earnings|forfeiture\s+of\s+all\s+compensation)\b"
        ],
        "explanation": "Specifies heavy financial penalties or total fee forfeiture for minor delivery delays or contract defaults.",
        "whyItMatters": "Disproportionate penalties can erase all your earnings for minor or unintended mistakes.",
        "recommendation": "Remove automatic forfeiture clauses; substitute with reasonable grace periods and remedies."
    },
    {
        "id": "distant_unfavorable_jurisdiction",
        "category": "Jurisdiction",
        "title": "Distant or Unfavorable Dispute Jurisdiction",
        "severity": "MEDIUM",
        "score": 50,
        "patterns": [
            r"(?i)\b(exclusive\s+jurisdiction\s+of\s+the\s+courts\s+of\s+(foreign|international|delaware|new\s+york|england|singapore|dubai))\b"
        ],
        "explanation": "Specifies a distant or foreign jurisdiction/venue for resolving disputes.",
        "whyItMatters": "If a dispute arises, traveling or hiring lawyers in a remote jurisdiction could be cost-prohibitive for a freelancer.",
        "recommendation": "Suggest your local jurisdiction or an accessible online mediation/arbitration procedure."
    },
    {
        "id": "broad_deductions_clawback",
        "category": "Deductions",
        "title": "Unilateral Deductions or Clawback Rights",
        "severity": "HIGH",
        "score": 75,
        "patterns": [
            r"(?i)\b(right\s+to\s+deduct\s+from\s+any\s+payments|withhold\s+or\s+offset\s+any\s+amounts|clawback\s+of\s+fees\s+paid)\b"
        ],
        "explanation": "The client may deduct money from your invoice or claw back paid fees at their own discretion.",
        "whyItMatters": "Creates payment instability where fees you already budgeted for can be withheld.",
        "recommendation": "Require itemized written dispute notices within 7 business days, with undisputed amounts paid on schedule."
    },
    {
        "id": "perpetual_broad_confidentiality",
        "category": "Confidentiality",
        "title": "Perpetual or Overly Broad Confidentiality",
        "severity": "LOW",
        "score": 40,
        "patterns": [
            r"(?i)\b(confidentiality\s+obligations\s+shall\s+survive\s+in\s+perpetuity|forever\s+maintain\s+secrecy|shall\s+never\s+disclose\s+any\s+aspect)\b"
        ],
        "explanation": "Confidentiality requirements last forever and cover broad, undefined categories of information.",
        "whyItMatters": "Could restrict your ability to showcase your portfolio, case studies, or general professional experience.",
        "recommendation": "Suggest standard 2 to 3-year confidentiality duration and explicit permission to list the client on your portfolio."
    }
]

# Potentially Misleading / Unfair Clause Patterns
MISLEADING_PATTERNS = [
    {
        "id": "vague_deliverables",
        "title": "Vague Deliverables or Subjective Acceptance",
        "patterns": [
            r"(?i)\b(to\s+the\s+complete\s+satisfaction\s+of\s+the\s+company|at\s+the\s+sole\s+and\s+absolute\s+discretion\s+of\s+the\s+client)\b",
            r"(?i)\b(any\s+other\s+duties\s+as\s+assigned\s+from\s+time\s+to\s+time|as\s+deemed\s+necessary\s+by\s+the\s+company)\b"
        ],
        "issueType": "Subjective Acceptance / Scope Vagueness",
        "explanation": "The criteria for acceptable work are defined subjectively ('sole satisfaction') rather than by clear objective deliverables.",
        "whyItMatters": "The client could repeatedly request revisions or refuse payment on subjective grounds without clear standards.",
        "recommendation": "Define precise acceptance criteria (e.g. 2 revision rounds, explicit written sign-off within 5 business days)."
    },
    {
        "id": "hidden_waiver_of_rights",
        "title": "Unilateral Waiver of Future Legal Claims",
        "patterns": [
            r"(?i)\b(hereby\s+waives\s+all\s+rights\s+to\s+trial\s+by\s+jury|waives\s+any\s+and\s+all\s+claims\s+now\s+or\s+in\s+the\s+future)\b",
            r"(?i)\b(waives\s+all\s+statutory\s+protections|releases\s+the\s+company\s+from\s+any\s+future\s+liability)\b"
        ],
        "issueType": "Rights Waiver",
        "explanation": "The clause contains broad language relinquishing future claims or statutory protections.",
        "whyItMatters": "May prevent you from seeking legal recourse even in cases of material breach by the counterparty.",
        "recommendation": "Review any broad release of claims with qualified legal counsel before signing."
    },
    {
        "id": "hidden_expense_absorption",
        "title": "Hidden Expense Burden Without Reimbursement",
        "patterns": [
            r"(?i)\b(contractor\s+shall\s+bear\s+all\s+costs\s+and\s+expenses|no\s+expenses\s+shall\s+be\s+reimbursed\s+unless\s+prior\s+written\s+authorization)\b",
            r"(?i)\b(all\s+equipment,?\s+software,?\s+and\s+licenses\s+at\s+contractor['’]?s\s+sole\s+expense)\b"
        ],
        "issueType": "Hidden Costs",
        "explanation": "All software licenses, tools, and operational expenses are pushed onto the worker without pre-agreed reimbursement.",
        "whyItMatters": "Your take-home earnings could be diminished by unexpected software, tool, or travel costs.",
        "recommendation": "Specify which party supplies necessary software, cloud licenses, or specialized tools."
    },
    {
        "id": "contradictory_status",
        "title": "Contractor Classification With Employee-like Controls",
        "patterns": [
            r"(?i)\b(independent\s+contractor.*?must\s+adhere\s+to\s+fixed\s+working\s+hours|must\s+work\s+exclusively\s+at\s+company\s+premises)\b",
            r"(?i)\b(subject\s+to\s+direct\s+supervision\s+and\s+company\s+disciplinary\s+policies)\b"
        ],
        "issueType": "Misclassification Risk",
        "explanation": "Labels you as an independent contractor, but imposes rigid employee-like controls (fixed office hours, direct supervision).",
        "whyItMatters": "Creates a one-sided arrangement where you lack employee benefits while facing employee-level restrictions.",
        "recommendation": "Clarify that you maintain autonomous control over your work hours and methods."
    }
]


def detect_risks_and_misleading_clauses(clauses: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], int]:
    """
    Scans extracted clauses for high-risk patterns and potentially misleading/one-sided terms.
    Returns:
    - risks_detected (list of structured risks)
    - misleading_clauses (list of structured misleading clauses)
    - aggregate_risk_score (0-100 integer)
    """
    detected_risks = []
    detected_misleading = []
    seen_risk_ids = set()
    seen_misleading_ids = set()

    for clause in clauses:
        text = clause.get("originalText", "")
        category = clause.get("category", "")
        page = clause.get("page", 1)

        # 1. Match Risk Rules
        for rule in RISK_RULES:
            rule_id = rule["id"]
            if rule_id in seen_risk_ids:
                continue

            matched = False
            for pat in rule["patterns"]:
                if re.search(pat, text):
                    matched = True
                    break

            if matched:
                seen_risk_ids.add(rule_id)
                detected_risks.append({
                    "id": f"risk_{rule_id}",
                    "category": rule["category"],
                    "title": rule["title"],
                    "severity": rule["severity"],
                    "score": rule["score"],
                    "originalText": text,
                    "page": page,
                    "explanation": rule["explanation"],
                    "whyItMatters": rule["whyItMatters"],
                    "recommendation": rule["recommendation"]
                })

        # 2. Match Potentially Misleading / Unfair Clauses
        for mis_rule in MISLEADING_PATTERNS:
            mis_id = mis_rule["id"]
            if mis_id in seen_misleading_ids:
                continue

            matched_mis = False
            for pat in mis_rule["patterns"]:
                if re.search(pat, text):
                    matched_mis = True
                    break

            if matched_mis:
                seen_misleading_ids.add(mis_id)
                detected_misleading.append({
                    "id": f"misleading_{mis_id}",
                    "title": mis_rule["title"],
                    "issueType": mis_rule["issueType"],
                    "category": category,
                    "originalText": text,
                    "page": page,
                    "explanation": mis_rule["explanation"],
                    "whyItMatters": mis_rule["whyItMatters"],
                    "recommendation": mis_rule["recommendation"]
                })

    # Calculate overall Risk Score (0-100)
    if not detected_risks:
        overall_risk_score = 15  # Baseline low risk for standard contracts
    else:
        # Weighted risk calculation
        critical_count = sum(1 for r in detected_risks if r["severity"] == "CRITICAL")
        high_count = sum(1 for r in detected_risks if r["severity"] == "HIGH")
        med_count = sum(1 for r in detected_risks if r["severity"] == "MEDIUM")
        low_count = sum(1 for r in detected_risks if r["severity"] == "LOW")

        calculated = (critical_count * 30) + (high_count * 20) + (med_count * 10) + (low_count * 5) + (len(detected_misleading) * 8)
        overall_risk_score = min(98, max(20, calculated))

    return detected_risks, detected_misleading, overall_risk_score
