"""
clause_extractor.py - Extracts and categorizes contract clauses using rule-based pattern matching.

Detects 20 contract clause categories:
- Payment
- Compensation
- Termination
- Notice Period
- Liability
- Indemnity
- Confidentiality
- Intellectual Property
- Data Privacy
- Arbitration
- Jurisdiction
- Non-compete
- Non-solicitation
- Exclusivity
- Working Hours
- Penalties
- Deductions
- Commission
- Renewal
- Cancellation
"""

import re
from typing import List, Dict, Any

# Keyword and pattern mappings for each category
CLAUSE_PATTERNS = {
    "Termination": [
        r"(?i)\b(termination|terminate|terminate\s+this\s+agreement|early\s+termination|grounds\s+for\s+termination|termination\s+for\s+convenience|termination\s+for\s+cause)\b",
        r"(?i)\b(right\s+to\s+cancel|cancel\s+the\s+agreement|immediate\s+termination)\b"
    ],
    "Notice Period": [
        r"(?i)\b(notice\s+period|prior\s+written\s+notice|\b\d+\s+(days?|weeks?|months?)\s+(prior\s+)?notice|without\s+notice|written\s+notice\s+of\s+termination)\b"
    ],
    "Payment": [
        r"(?i)\b(payment\s+terms|fee|fees|invoice|invoicing|remuneration|payment\s+schedule|due\s+date|net\s+\d+|payable\s+within|payment\s+method|bank\s+transfer)\b",
        r"(?i)\b(milestone\s+payments?|advance\s+payment|retainer)\b"
    ],
    "Compensation": [
        r"(?i)\b(compensation|salary|hourly\s+rate|fixed\s+fee|stipend|consideration|rate\s+of\s+pay|overtime\s+pay|expenses?\s+reimbursement)\b"
    ],
    "Liability": [
        r"(?i)\b(limitation\s+of\s+liability|liability|liable|damages|consequential\s+damages|indirect\s+damages|maximum\s+liability|unlimited\s+liability|in\s+no\s+event\s+shall)\b"
    ],
    "Indemnity": [
        r"(?i)\b(indemnif(y|ication|ied)|hold\s+harmless|defend\s+and\s+hold\s+harmless|indemnity\s+obligations?)\b"
    ],
    "Confidentiality": [
        r"(?i)\b(confidential\s+information|confidentiality|non-disclosure|proprietary\s+information|trade\s+secrets|duty\s+of\s+confidentiality)\b"
    ],
    "Intellectual Property": [
        r"(?i)\b(intellectual\s+property|ip\s+rights|work\s+made\s+for\s+hire|assignment\s+of\s+inventions|copyright|ownership\s+of\s+work|moral\s+rights|patent|trademark|proprietary\s+rights)\b"
    ],
    "Data Privacy": [
        r"(?i)\b(data\s+privacy|gdpr|personal\s+data|privacy\s+policy|data\s+protection|data\s+processing|confidential\s+data)\b"
    ],
    "Arbitration": [
        r"(?i)\b(arbitration|arbitrator|dispute\s+resolution|binding\s+arbitration|american\s+arbitration\s+association|arbitral\s+tribunal)\b"
    ],
    "Jurisdiction": [
        r"(?i)\b(governing\s+law|jurisdiction|applicable\s+law|courts?\s+of|venue|exclusive\s+jurisdiction|choice\s+of\s+law)\b"
    ],
    "Non-compete": [
        r"(?i)\b(non-compete|non\s+compete|covenant\s+not\s+to\s+compete|restrictive\s+covenants?|competing\s+business|shall\s+not\s+engage\s+in\s+any\s+business)\b"
    ],
    "Non-solicitation": [
        r"(?i)\b(non-solicitation|non\s+solicitation|solicit\s+employees|solicit\s+clients|solicit\s+customers|entice\s+away)\b"
    ],
    "Exclusivity": [
        r"(?i)\b(exclusivity|exclusive\s+basis|exclusive\s+services|sole\s+and\s+exclusive|exclusive\s+rights|not\s+work\s+for\s+any\s+other)\b"
    ],
    "Working Hours": [
        r"(?i)\b(working\s+hours|business\s+hours|overtime|time\s+commitment|availability|expected\s+hours|shift\s+timings)\b"
    ],
    "Penalties": [
        r"(?i)\b(penalt(y|ies)|liquidated\s+damages|late\s+fee|default\s+charge|forfeit|penalty\s+clause)\b"
    ],
    "Deductions": [
        r"(?i)\b(deductions?|withholding|set-off|deduct\s+from\s+payment|withhold\s+payment|clawback)\b"
    ],
    "Commission": [
        r"(?i)\b(commission|revenue\s+share|profit\s+share|bonus\s+structure|percentage\s+of\s+sales|incentive\s+pay)\b"
    ],
    "Renewal": [
        r"(?i)\b(automatic\s+renewal|auto-renew|renewal\s+term|extension\s+of\s+term|renewed\s+automatically|successive\s+periods)\b"
    ],
    "Cancellation": [
        r"(?i)\b(cancellation|cancel\s+order|order\s+cancellation|cancellation\s+fee|cooling-off\s+period)\b"
    ]
}


def segment_contract_into_clauses(text: str, pages_data: list = None) -> List[Dict[str, Any]]:
    """
    Segments raw contract text into structured clause units and identifies their category and page.
    """
    if not text:
        return []

    # Split on double newlines or numbered headers like "1.", "Section 2", "Article III", etc.
    raw_blocks = re.split(r'(?m)(?=(?:^[A-Z\s]{4,}:|^\d+\.\s+|^Section\s+\d+|^Article\s+[IVX\d]+|\n\n\s*))', text)
    
    # Filter out trivial chunks
    blocks = [b.strip() for b in raw_blocks if len(b.strip()) > 30]

    if not blocks:
        # Fallback to paragraph splitting
        blocks = [p.strip() for p in text.split('\n\n') if len(p.strip()) > 30]

    extracted_clauses = []
    seen_texts = set()

    for idx, block in enumerate(blocks):
        clean_block = block.strip()
        if clean_block in seen_texts:
            continue
        seen_texts.add(clean_block)

        # Detect matching categories
        matched_categories = []
        for category, patterns in CLAUSE_PATTERNS.items():
            for pat in patterns:
                if re.search(pat, clean_block):
                    matched_categories.append(category)
                    break

        # If no explicit category matched, label as "General Terms" if sufficiently long
        if not matched_categories:
            if len(clean_block) > 60 and any(kw in clean_block.lower() for kw in ["agree", "party", "parties", "hereby", "shall", "covenant"]):
                matched_categories.append("General Terms")
            else:
                continue

        # Determine estimated page number
        page_num = 1
        if pages_data:
            for p in pages_data:
                # If a significant snippet of the clause exists on this page
                snippet = clean_block[:80]
                if snippet in p.get("text", ""):
                    page_num = p.get("pageNumber", 1)
                    break

        for cat in matched_categories:
            # Extract clean title/heading if present
            heading_match = re.match(r'^((?:Section\s+\d+|Article\s+[IVX\d]+|\d+\.|\b[A-Z\s]{3,}\b)[^.\n:]+[:.]?)', clean_block)
            clause_title = heading_match.group(1).strip() if heading_match else cat

            extracted_clauses.append({
                "id": f"clause_{idx}_{cat.lower().replace(' ', '_')}",
                "category": cat,
                "title": clause_title,
                "originalText": clean_block,
                "page": page_num,
                "charCount": len(clean_block)
            })

    return extracted_clauses
