"""
main.py - FastAPI AI & Document Processing Microservice for RiskOff.

Features:
- 100% Local & Free Execution
- Zero paid API dependencies
- PyMuPDF text extraction with Tesseract OCR fallback
- DOCX Microsoft Word document extraction
- Categorized clause extraction, risk detection, transparency scoring, and multi-language support
"""

import os
import io
import logging
from typing import Optional
from fastapi import FastAPI, File, UploadFile, Form, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

from pdf_service import extract_pdf_content, extract_docx_content
from ocr_service import extract_text_from_image, get_ocr_status
from text_cleaner import clean_text
from analyzer import analyze_contract
from ollama_service import is_ollama_available
from language_service import SUPPORTED_LANGUAGES

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("riskoff-ai")

app = FastAPI(
    title="RiskOff AI Service",
    description="Local, Zero-Cost Contract Analysis & Extraction Service",
    version="1.1.0"
)

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeTextRequest(BaseModel):
    text: str
    preferredLanguage: Optional[str] = "en"


@app.get("/health")
async def health_check():
    """
    Returns system status, active AI provider, OCR availability, and Ollama status.
    """
    ocr_info = get_ocr_status()
    ollama_info = await is_ollama_available()
    provider = os.getenv("AI_PROVIDER", "rule_based")

    return {
        "status": "online",
        "service": "RiskOff AI Microservice",
        "version": "1.1.0",
        "configured_ai_provider": provider,
        "ocr": ocr_info,
        "ollama": ollama_info,
        "supported_languages": list(SUPPORTED_LANGUAGES.keys())
    }


@app.post("/extract-text")
async def extract_text_endpoint(file: UploadFile = File(...)):
    """
    Extracts raw text from an uploaded PDF, DOCX, or image file.
    """
    filename = file.filename or "document"
    contents = await file.read()

    if not contents:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    ext = os.path.splitext(filename)[1].lower()

    if ext == ".pdf":
        try:
            result = extract_pdf_content(contents)
            return {
                "fileName": filename,
                "fileType": "pdf",
                "pageCount": result["pageCount"],
                "totalCharacters": result["totalCharacters"],
                "needsOCR": result["needsOCR"],
                "ocrAttempted": result["ocrAttempted"],
                "text": result["text"]
            }
        except Exception as e:
            logger.error(f"PDF extraction error: {e}")
            raise HTTPException(status_code=422, detail=f"Failed to extract PDF text: {str(e)}")

    elif ext == ".docx":
        try:
            result = extract_docx_content(contents)
            return {
                "fileName": filename,
                "fileType": "docx",
                "pageCount": result["pageCount"],
                "totalCharacters": result["totalCharacters"],
                "needsOCR": False,
                "ocrAttempted": False,
                "text": result["text"]
            }
        except Exception as e:
            logger.error(f"DOCX extraction error: {e}")
            raise HTTPException(status_code=422, detail=f"Failed to extract DOCX text: {str(e)}")

    elif ext in [".png", ".jpg", ".jpeg"]:
        try:
            extracted = extract_text_from_image(contents)
            cleaned = clean_text(extracted)
            return {
                "fileName": filename,
                "fileType": "image",
                "pageCount": 1,
                "totalCharacters": len(cleaned),
                "needsOCR": True,
                "ocrAttempted": True,
                "text": cleaned
            }
        except Exception as e:
            logger.error(f"Image OCR error: {e}")
            raise HTTPException(status_code=422, detail=f"Failed to OCR image: {str(e)}")

    else:
        # Attempt direct text decoding if plain text
        try:
            text = contents.decode("utf-8", errors="ignore")
            cleaned = clean_text(text)
            return {
                "fileName": filename,
                "fileType": "text",
                "pageCount": 1,
                "totalCharacters": len(cleaned),
                "needsOCR": False,
                "ocrAttempted": False,
                "text": cleaned
            }
        except Exception:
            raise HTTPException(status_code=400, detail=f"Unsupported file format: {ext}")


@app.post("/ocr")
async def ocr_endpoint(file: UploadFile = File(...)):
    """
    Direct OCR endpoint for images.
    """
    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Empty file provided.")

    text = extract_text_from_image(contents)
    return {
        "fileName": file.filename,
        "ocrEngine": "Tesseract",
        "text": clean_text(text)
    }


@app.post("/analyze")
async def analyze_endpoint(
    file: Optional[UploadFile] = File(None),
    text: Optional[str] = Form(None),
    preferredLanguage: Optional[str] = Form("en")
):
    """
    Comprehensive contract analysis endpoint.
    Accepts either an uploaded file (multipart) or raw text.
    """
    extracted_text = ""
    pages_data = None

    if file:
        filename = file.filename or "contract"
        contents = await file.read()
        if not contents:
            raise HTTPException(status_code=400, detail="Uploaded file is empty.")

        ext = os.path.splitext(filename)[1].lower()
        if ext == ".pdf":
            try:
                pdf_res = extract_pdf_content(contents)
                extracted_text = pdf_res["text"]
                pages_data = pdf_res.get("pages", [])
            except Exception as e:
                raise HTTPException(status_code=422, detail=f"PDF extraction error: {str(e)}")
        elif ext == ".docx":
            try:
                docx_res = extract_docx_content(contents)
                extracted_text = docx_res["text"]
                pages_data = docx_res.get("pages", [])
            except Exception as e:
                raise HTTPException(status_code=422, detail=f"DOCX extraction error: {str(e)}")
        elif ext in [".png", ".jpg", ".jpeg"]:
            extracted_text = clean_text(extract_text_from_image(contents))
        else:
            extracted_text = clean_text(contents.decode("utf-8", errors="ignore"))

    elif text:
        extracted_text = clean_text(text)
    else:
        raise HTTPException(status_code=400, detail="Either 'file' or 'text' must be provided for analysis.")

    if not extracted_text or len(extracted_text.strip()) < 10:
        raise HTTPException(
            status_code=422,
            detail="Could not extract readable text from document. If it is a scanned image, please ensure Tesseract OCR is installed."
        )

    try:
        analysis_result = await analyze_contract(
            raw_text=extracted_text,
            preferred_language=preferredLanguage or "en",
            pages_data=pages_data
        )
        return analysis_result
    except Exception as e:
        logger.error(f"Analysis processing error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Analysis pipeline error: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "127.0.0.1")
    uvicorn.run("main:app", host=host, port=port, reload=True)
