"""
ocr_service.py - Free, local OCR processing using Tesseract and Pillow.

Handles:
- Image file OCR (PNG, JPG, JPEG)
- Scanned PDF page image OCR
- Automatic detection of Tesseract binary location
- Graceful degradation if Tesseract binary is not installed
"""

import os
import io
import shutil
import logging
from PIL import Image
import pytesseract
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# Common Tesseract binary locations on various OS platforms
COMMON_TESSERACT_PATHS = [
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    r"C:\Users\DELL\AppData\Local\Programs\Tesseract-OCR\tesseract.exe",
    "/usr/bin/tesseract",
    "/usr/local/bin/tesseract",
    "/opt/homebrew/bin/tesseract",
]


def _configure_tesseract():
    """Configures pytesseract with the appropriate binary path."""
    env_path = os.getenv("TESSERACT_PATH", "").strip()
    if env_path and os.path.exists(env_path):
        pytesseract.pytesseract.tesseract_cmd = env_path
        return

    # Check if 'tesseract' is globally available in system PATH
    which_tesseract = shutil.which("tesseract")
    if which_tesseract:
        pytesseract.pytesseract.tesseract_cmd = which_tesseract
        return

    # Check common installation directories
    for path in COMMON_TESSERACT_PATHS:
        if os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            return


_configure_tesseract()


def is_tesseract_available() -> bool:
    """Returns True if Tesseract OCR binary is detected and executable."""
    try:
        _configure_tesseract()
        version = pytesseract.get_tesseract_version()
        return bool(version)
    except Exception:
        return False


def get_ocr_status() -> dict:
    """Returns current OCR engine configuration and availability status."""
    available = is_tesseract_available()
    cmd = pytesseract.pytesseract.tesseract_cmd
    return {
        "available": available,
        "binary_path": cmd if available else None,
        "engine": "Tesseract (Local / Zero-Cost)",
        "message": "Tesseract OCR is ready." if available else (
            "Tesseract OCR is not installed or not in PATH. "
            "Digital PDFs will still work with direct text extraction. "
            "To enable OCR for scanned images, please install Tesseract."
        )
    }


def extract_text_from_image(image_input) -> str:
    """
    Extracts text from a PIL Image, bytes, or file path using Tesseract OCR.
    """
    if not is_tesseract_available():
        logger.warning("OCR requested but Tesseract binary is not installed.")
        return "[OCR Notice: Tesseract OCR is not installed on the server. Scanned text could not be extracted.]"

    try:
        image = None
        if isinstance(image_input, bytes):
            image = Image.open(io.BytesIO(image_input))
        elif isinstance(image_input, str):
            image = Image.open(image_input)
        elif isinstance(image_input, Image.Image):
            image = image_input
        else:
            raise ValueError("Unsupported image input type for OCR.")

        # Convert to RGB if needed (e.g. RGBA or Palette)
        if image.mode not in ("L", "RGB"):
            image = image.convert("RGB")

        text = pytesseract.image_to_string(image, lang="eng")
        return text.strip()
    except Exception as e:
        logger.error(f"Error during OCR execution: {e}")
        return f"[OCR Error: {str(e)}]"
