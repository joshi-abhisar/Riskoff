"""
pdf_service.py - Fast and local PDF and DOCX extraction using PyMuPDF (fitz) and python-docx.

First attempts high-speed digital text extraction.
If pages contain scanned images or insufficient text, conditionally triggers OCR.
"""

import io
import logging
import fitz  # PyMuPDF
from PIL import Image
import docx
from ocr_service import extract_text_from_image, is_tesseract_available
from text_cleaner import clean_text

logger = logging.getLogger(__name__)

# Minimum characters per page to consider digital text valid
MIN_CHARS_PER_PAGE = 50


def extract_pdf_content(file_bytes: bytes) -> dict:
    """
    Extracts text from PDF bytes. Uses digital extraction first, falling back to OCR
    for pages with insufficient text.
    """
    try:
        doc = fitz.open(stream=file_bytes, filetype="pdf")
    except Exception as e:
        logger.error(f"Failed to open PDF document: {e}")
        raise ValueError(f"Invalid or corrupted PDF file: {str(e)}")

    page_count = len(doc)
    extracted_pages = []
    total_chars = 0
    needs_ocr_count = 0
    ocr_attempted = False

    for page_index in range(page_count):
        page = doc.load_page(page_index)
        page_num = page_index + 1
        page_text = page.get_text("text").strip()

        # Check if page has sufficient text
        if len(page_text) < MIN_CHARS_PER_PAGE:
            needs_ocr_count += 1
            if is_tesseract_available():
                ocr_attempted = True
                try:
                    # Render page to high-res image (150 dpi for OCR)
                    pix = page.get_pixmap(dpi=150)
                    img = Image.open(io.BytesIO(pix.tobytes("png")))
                    ocr_text = extract_text_from_image(img)
                    if len(ocr_text) > len(page_text):
                        page_text = ocr_text
                except Exception as err:
                    logger.warning(f"OCR failed for page {page_num}: {err}")

        cleaned = clean_text(page_text)
        total_chars += len(cleaned)

        extracted_pages.append({
            "pageNumber": page_num,
            "text": cleaned,
            "charCount": len(cleaned),
            "wasOCR": len(page_text) < MIN_CHARS_PER_PAGE and is_tesseract_available()
        })

    doc.close()

    full_text = "\n\n".join([p["text"] for p in extracted_pages if p["text"]])

    return {
        "text": full_text,
        "pageCount": page_count,
        "totalCharacters": total_chars,
        "needsOCR": needs_ocr_count > 0,
        "ocrAttempted": ocr_attempted,
        "pages": extracted_pages
    }


def extract_docx_content(file_bytes: bytes) -> dict:
    """
    Extracts text from Microsoft Word (.docx) documents.
    """
    try:
        doc = docx.Document(io.BytesIO(file_bytes))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        full_text = clean_text("\n\n".join(paragraphs))
        return {
            "text": full_text,
            "pageCount": max(1, len(paragraphs) // 5),
            "totalCharacters": len(full_text),
            "needsOCR": False,
            "ocrAttempted": False,
            "pages": [{"pageNumber": 1, "text": full_text, "charCount": len(full_text), "wasOCR": False}]
        }
    except Exception as e:
        logger.error(f"Failed to read DOCX file: {e}")
        raise ValueError(f"Invalid DOCX file format: {str(e)}")
