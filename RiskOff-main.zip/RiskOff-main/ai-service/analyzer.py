"""
analyzer.py - Full contract analysis pipeline orchestrator.

Coordinates:
1. Text normalization & cleaning
2. Structured clause segmentation (20+ categories)
3. Risk & one-sided term detection
4. Potentially misleading clause detection
5. RiskOff Risk Indicator calculation (0-100)
6. Transparency Score calculation (0-100)
7. Multi-language executive summary & takeaway generation
8. Actionable clarification recommendations
9. Optional Ollama enhancement with strict fallback
"""

import os
import logging
from typing import Dict, Any, List

from text_cleaner import clean_text
from clause_extractor import segment_contract_into_clauses
from risk_detector import detect_risks_and_misleading_clauses
from language_service import localize_risk_item, generate_localized_summary, SUPPORTED_LANGUAGES
from ollama_service import is_ollama_available, generate_ollama_explanation

logger = logging.getLogger(__name__)


def calculate_transparency_score(
    clauses: List[Dict[str, Any]],
    misleading_clauses: List[Dict[str, Any]],
    risks: List[Dict[str, Any]]
) -> tuple[int, str]:
    """
    Computes a Transparency Score (0-100) indicating how clearly obligations are articulated.
    """
    score = 100

    # Deduct for misleading/vague items
    score -= len(misleading_clauses) * 12

    # Deduct for high/critical risks that hide obligations
    critical_or_high_risks = [r for r in risks if r.get("severity") in ("CRITICAL", "HIGH")]
    score -= len(critical_or_high_risks) * 8

    # Deduct for clauses with high complexity or extreme length (> 1200 chars without breaks)
    complex_clauses = [c for c in clauses if c.get("charCount", 0) > 1000]
    score -= len(complex_clauses) * 5

    # Check if payment or termination clauses are completely missing (clarity gap)
    categories = {c.get("category") for c in clauses}
    if "Payment" not in categories and "Compensation" not in categories:
        score -= 10
    if "Termination" not in categories and "Notice Period" not in categories:
        score -= 10

    final_score = max(15, min(95, score))

    if final_score >= 80:
        level = "HIGH TRANSPARENCY"
    elif final_score >= 55:
        level = "MODERATE TRANSPARENCY"
    else:
        level = "NEEDS ATTENTION"

    return final_score, level


def get_risk_level_label(score: int) -> str:
    if score >= 76:
        return "CRITICAL RISK"
    elif score >= 51:
        return "HIGH RISK"
    elif score >= 26:
        return "MODERATE RISK"
    return "LOW RISK"


async def analyze_contract(
    raw_text: str,
    preferred_language: str = "en",
    pages_data: list = None
) -> Dict[str, Any]:
    """
    Main asynchronous analysis function.
    """
    cleaned_text = clean_text(raw_text)

    # 1. Segment into categorized clauses
    clauses = segment_contract_into_clauses(cleaned_text, pages_data)

    # 2. Detect risks and misleading clauses
    risks, misleading, risk_score = detect_risks_and_misleading_clauses(clauses)
    risk_level = get_risk_level_label(risk_score)

    # 3. Calculate Transparency Score
    transparency_score, transparency_level = calculate_transparency_score(clauses, misleading, risks)

    # 4. Generate Localized Summary & Takeaways
    lang = preferred_language.lower().strip()
    if lang not in SUPPORTED_LANGUAGES:
        lang = "en"

    summary_data = generate_localized_summary(
        doc_type="Service Agreement",
        clause_count=len(clauses),
        risk_count=len(risks),
        misleading_count=len(misleading),
        risk_score=risk_score,
        lang_code=lang
    )

    # 5. Localize Risk Items and Misleading Items for the target language
    localized_risks = [localize_risk_item(r, lang) for r in risks]
    localized_misleading = [localize_risk_item(m, lang) for m in misleading]

    # 6. Generate Actionable Clarification Recommendations
    recommendations = []
    for r in localized_risks:
        if r.get("recommendation") and r["recommendation"] not in recommendations:
            recommendations.append(r["recommendation"])
    for m in localized_misleading:
        if m.get("recommendation") and m["recommendation"] not in recommendations:
            recommendations.append(m["recommendation"])

    if not recommendations:
        if lang == "hi":
            recommendations.append("अनुबंध पर हस्ताक्षर करने से पहले भुगतान की तारीख और काम की स्वीकृति के नियम लिखित में स्पष्ट करें।")
        elif lang == "hinglish":
            recommendations.append("Contract sign karne se pehle payment timeline aur deliverable approval criteria clarify kar lein.")
        else:
            recommendations.append("Confirm all deliverable timelines, payment milestones, and notice periods in writing.")

    # 7. Check if AI_PROVIDER=ollama is requested and available
    ai_provider = os.getenv("AI_PROVIDER", "rule_based").lower()
    used_provider = "rule_based"

    if ai_provider == "ollama":
        ollama_status = await is_ollama_available()
        if ollama_status["available"] and ollama_status["model_ready"]:
            used_provider = "ollama"
            # Optional LLM refinement prompt
            prompt = (
                f"Summarize this legal contract in 3 simple bullet points in {SUPPORTED_LANGUAGES[lang]['name']}:\n"
                f"{cleaned_text[:1500]}"
            )
            llm_res = await generate_ollama_explanation(prompt)
            if llm_res:
                summary_data["summaryText"] = llm_res

    return {
        "preferredLanguage": lang,
        "languageName": SUPPORTED_LANGUAGES.get(lang, {}).get("name", "English"),
        "aiProvider": used_provider,
        "riskScore": risk_score,
        "riskLevel": risk_level,
        "transparencyScore": transparency_score,
        "transparencyLevel": transparency_level,
        "summary": summary_data["summaryText"],
        "keyTakeaways": summary_data["keyTakeaways"],
        "risks": localized_risks,
        "potentiallyMisleadingClauses": localized_misleading,
        "importantClauses": clauses,
        "recommendations": recommendations,
        "extractedText": cleaned_text,
        "stats": {
            "totalClauses": len(clauses),
            "totalRisks": len(risks),
            "totalMisleading": len(misleading),
            "criticalRisks": sum(1 for r in risks if r.get("severity") == "CRITICAL"),
            "highRisks": sum(1 for r in risks if r.get("severity") == "HIGH"),
            "mediumRisks": sum(1 for r in risks if r.get("severity") == "MEDIUM"),
            "lowRisks": sum(1 for r in risks if r.get("severity") == "LOW"),
        }
    }
