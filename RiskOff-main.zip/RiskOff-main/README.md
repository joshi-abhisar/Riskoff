# RISKOFF — AI CONTRACT ANALYZER

> **"Understand your contract before you sign."**

RiskOff is a zero-cost, local-first, AI-assisted legal contract analyzer built for freelancers, gig workers, creators, independent contractors, students, and everyday individuals who need clear, straightforward explanations of complicated agreements.

---

## 🌟 Key Features

1. **Zero Paid APIs & Local-First**: No OpenAI, Anthropic, Gemini, AWS, GCP, or Azure keys required. All text parsing, clause categorization, risk detection, transparency scoring, and multi-language explanations run 100% locally and freely.
2. **Fast Digital PDF Parsing**: PyMuPDF (`fitz`) extracts digital text instantly with page-level tracking.
3. **Local OCR for Scanned Documents**: Free, local Tesseract OCR integration for scanned PDFs, photo uploads, PNG, and JPG images with graceful degradation if the Tesseract binary is not installed.
4. **20+ Categorized Clause Types**: Automatically identifies Payment, Compensation, Notice Period, Termination, Liability, Indemnity, Intellectual Property, Confidentiality, Non-compete, Non-solicitation, Exclusivity, Working Hours, Penalties, Deductions, Commission, Renewal, Cancellation, and more.
5. **High-Risk Clause Detection**: Flags 18+ dangerous terms including termination without notice, unlimited liability, broad IP transfers, perpetual rights, and unreasonable non-competes.
6. **Potentially Misleading / One-Sided Clauses**: Dedicated engine detecting subjective acceptance criteria, unilateral modification rights, hidden expense burdens, and contractor-employee misclassifications using responsible legal phrasing.
7. **RiskOff Risk Indicator (0-100)**: Visual gauge classifying risk into LOW, MODERATE, HIGH, and CRITICAL severity tiers.
8. **Transparency Score (0-100)**: Independent metric evaluating clarity of obligations, term ambiguity, and absence of hidden clauses.
9. **Multi-Language Support (11 Languages)**: Generates executive summaries, key takeaways, and simple explanations in **English, Hindi (हिंदी), Hinglish, Bengali (বাংলা), Marathi (मराठी), Tamil (தமிழ்), Telugu (తెలుగు), Gujarati (ગુજરાતી), Kannada (ಕನ್ನಡ), Malayalam (മലയാളം), and Punjabi (ਪੰਜਾਬੀ)** while strictly preserving the original contract text.
10. **Actionable Clarification Recommendations**: Specific, numbered counter-proposals to ask before signing.
11. **Secure JWT Authentication & User Isolation**: Encrypted passwords (bcryptjs), protected REST routes, and strict ownership isolation.
12. **Complete Contract History**: Search, filter by risk level, re-open past analyses, change explanation languages on the fly, print reports, or permanently delete files.
13. **Optional Local Ollama LLM Integration**: Connects seamlessly to a local Ollama instance (`http://localhost:11434`, `llama3.2`) with automatic fallback to the built-in rule-based engine when offline.

---

## 🏛️ System Architecture

```
                ┌────────────────────────────────────────┐
                │          React 18 + Vite UI            │
                │        (Port 5173 / Tailwind)          │
                └───────────────────┬────────────────────┘
                                    │ HTTP / JSON / JWT
                                    ▼
                ┌────────────────────────────────────────┐
                │       Node.js / Express Backend        │
                │    (Port 5000 / Auth, Files, DB)       │
                └─────────┬───────────────────┬──────────┘
                          │                   │
                 Mongoose │                   │ Axios Multipart
                          ▼                   ▼
                ┌───────────────────┐ ┌───────────────────────────────────┐
                │   MongoDB local   │ │      FastAPI AI Microservice      │
                │   or Atlas Free   │ │  (Port 8000 / PyMuPDF & OCR Engine) │
                └───────────────────┘ └─────────────────┬─────────────────┘
                                                        │
                                          ┌─────────────┴─────────────┐
                                          ▼                           ▼
                             ┌────────────────────────┐  ┌────────────────────────┐
                             │   Rule-Based Engine    │  │ Optional Local Ollama  │
                             │ (100% Free / 11 Langs) │  │  (llama3.2 / phi3 etc) │
                             └────────────────────────┘  └────────────────────────┘
```

---

## 📁 Folder Structure

```
RiskOff/
├── client/                     # React + Vite Frontend
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx      # Navigation header & auth state
│   │   │   ├── Sidebar.jsx     # Dashboard navigation bar
│   │   │   ├── FileUpload.jsx  # Drag & drop upload + language picker
│   │   │   ├── ScoreCard.jsx   # Risk & Transparency visual gauges
│   │   │   ├── RiskCard.jsx    # High-risk clause warning cards
│   │   │   ├── MisleadingCard.jsx # One-sided / vague term cards
│   │   │   ├── ClauseCard.jsx  # Categorized clause viewer
│   │   │   └── LoadingState.jsx # Real-time analysis progress steps
│   │   ├── pages/
│   │   │   ├── Home.jsx        # Landing page & legal disclaimer
│   │   │   ├── Login.jsx       # Login form
│   │   │   ├── Register.jsx    # Registration form
│   │   │   ├── Dashboard.jsx   # User statistics & contract history
│   │   │   ├── Upload.jsx      # Dedicated upload & analyze screen
│   │   │   ├── Analysis.jsx    # Flagship interactive analysis report
│   │   │   └── Settings.jsx    # System health diagnostics inspector
│   │   ├── services/
│   │   │   └── api.js          # Axios client with JWT interceptor
│   │   ├── context/
│   │   │   └── AuthContext.jsx # Authentication state provider
│   │   ├── App.jsx             # React Router routing configuration
│   │   ├── main.jsx            # React root mount
│   │   └── index.css           # Tailwind base styles
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
│
├── server/                     # Node.js + Express Backend API
│   ├── models/
│   │   ├── User.js             # User Mongoose schema
│   │   ├── Contract.js         # Contract document schema
│   │   └── Analysis.js         # Contract Analysis report schema
│   ├── routes/
│   │   ├── auth.js             # Register, Login, Me, Logout
│   │   ├── contracts.js        # Upload, List, Get, Delete
│   │   └── analysis.js         # Analyze proxy & report retrieval
│   ├── middleware/
│   │   └── auth.js             # JWT bearer token verification
│   ├── uploads/                # Private contract storage (.gitkeep)
│   ├── server.js               # Express entrypoint & health checks
│   ├── package.json
│   └── .env.example
│
├── ai-service/                 # Python FastAPI AI & Document Processing
│   ├── main.py                 # FastAPI microservice routes
│   ├── pdf_service.py          # PyMuPDF digital extraction
│   ├── ocr_service.py          # Local Tesseract OCR with fallback
│   ├── text_cleaner.py         # Legal text formatting & cleaning
│   ├── clause_extractor.py     # 20+ clause category segmentation
│   ├── risk_detector.py        # 18+ high-risk & misleading heuristics
│   ├── language_service.py     # Multi-language translator (11 langs)
│   ├── ollama_service.py       # Optional Ollama client with fallback
│   ├── analyzer.py             # Orchestrator & score calculator
│   ├── requirements.txt
│   └── .env.example
│
├── sample_contracts/           # Sample contracts for testing
│   ├── freelance_high_risk.txt # High-risk freelancer agreement
│   └── sample_freelancer_agreement.pdf # Real PDF contract
├── .gitignore
└── README.md
```

---

## 🚀 Quick Start & Installation

RiskOff is designed to be run locally in three terminal windows.

### Prerequisites
- **Node.js**: v18 or higher (tested on Node v24)
- **Python**: v3.10 or higher (tested on Python 3.12)
- **MongoDB**: Local MongoDB community service or free MongoDB Atlas cluster

---

### Terminal 1: AI Microservice (FastAPI)

```bash
cd ai-service

# Windows:
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
python -m uvicorn main:app --reload --port 8000

# macOS / Linux:
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 -m uvicorn main:app --reload --port 8000
```
*Health Check*: `http://127.0.0.1:8000/health`

---

### Terminal 2: Node.js Backend API

```bash
cd server
npm install
npm run dev
```
*Health Check*: `http://127.0.0.1:5000/api/health`

---

### Terminal 3: React Frontend (Vite)

```bash
cd client
npm install
npm run dev
```
*Frontend Web App*: `http://localhost:5173`

---

## ⚙️ Environment Variables

### AI Service (`ai-service/.env`)
```env
PORT=8000
HOST=127.0.0.1

# AI Provider: "rule_based" (default, 100% free offline) or "ollama" (optional local LLM)
AI_PROVIDER=rule_based

# Optional Ollama configuration
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2

# Optional custom path to tesseract binary if not in system PATH:
TESSERACT_PATH=
```

### Backend Server (`server/.env`)
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://127.0.0.1:27017/riskoff
JWT_SECRET=riskoff_super_secure_jwt_local_secret_key_2026
AI_SERVICE_URL=http://127.0.0.1:8000
CLIENT_URL=http://localhost:5173
```

---

## 🗄️ MongoDB Setup

1. **Local MongoDB (Recommended for offline use)**:
   - Ensure MongoDB community service is running on `mongodb://127.0.0.1:27017/riskoff`.
2. **MongoDB Atlas (Free Tier Alternative)**:
   - Create a free M0 cluster at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
   - Copy the connection URI into `server/.env`:
     ```env
     MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/riskoff?retryWrites=true&w=majority
     ```

---

## 🔍 Tesseract OCR Setup (Optional for scanned images)

PyMuPDF extracts digital PDFs natively without Tesseract. If you wish to OCR scanned image documents (PNG, JPG, or image-only scanned PDFs):

- **Windows**: Download installer from [UB-Mannheim Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki). Install to `C:\Program Files\Tesseract-OCR` or specify `TESSERACT_PATH=C:\Program Files\Tesseract-OCR\tesseract.exe` in `ai-service/.env`.
- **macOS**: `brew install tesseract`
- **Linux (Ubuntu/Debian)**: `sudo apt-get install tesseract-ocr`

*Graceful Degradation*: If Tesseract is not installed, digital PDFs will continue to extract and analyze without any errors.

---

## 🦙 Optional Ollama Local AI Setup

RiskOff works completely out of the box using its built-in rule-based engine (`AI_PROVIDER=rule_based`).

If you wish to optionally enhance summaries with a local LLM:
1. Install [Ollama](https://ollama.com).
2. Pull a lightweight model:
   ```bash
   ollama run llama3.2
   ```
3. Set `AI_PROVIDER=ollama` in `ai-service/.env`.
4. If Ollama is closed or offline, RiskOff automatically and silently falls back to the rule-based engine.

---

## 📡 API Reference

### Node / Express API (`http://localhost:5000`)
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/api/auth/register` | No | Register new user account |
| `POST` | `/api/auth/login` | No | Authenticate user & issue JWT |
| `GET` | `/api/auth/me` | Bearer | Get current user profile |
| `POST` | `/api/auth/logout` | No | Terminate session |
| `POST` | `/api/contracts/upload` | Bearer | Upload PDF / image file (max 10MB) |
| `GET` | `/api/contracts` | Bearer | List user's contracts & summaries |
| `GET` | `/api/contracts/:id` | Bearer | Get contract & full analysis details |
| `DELETE` | `/api/contracts/:id` | Bearer | Cascade delete contract, file, and analysis |
| `POST` | `/api/analyze/:contractId`| Bearer | Run analysis with chosen language |
| `GET` | `/api/analyze/:contractId`| Bearer | Retrieve saved analysis report |
| `GET` | `/api/health` | No | Backend & microservice health status |

### Python FastAPI Microservice (`http://localhost:8000`)
| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | Service status, OCR path, Ollama connection, supported languages |
| `POST` | `/extract-text` | Extract text from uploaded PDF or image file |
| `POST` | `/ocr` | Run direct Tesseract OCR on image |
| `POST` | `/analyze` | Complete analysis pipeline (file or raw text) |

---

## ⚖️ Legal Safety & Ethical Principles

RiskOff adheres strictly to responsible legal-tech principles:
- **Informational Only**: The system acts as a self-review assistant, never presenting itself as a certified attorney or legal authority.
- **Objective Language**: Evaluates clauses as *"Potentially misleading"*, *"Unusually broad"*, *"Requires clarification"*, or *"May create additional obligations"*, avoiding definitive assertions like *"This contract is illegal"* or *"This company is fraudulent"*.
- **Original Text Preservation**: The original clause text is never modified, ensuring users always see verbatim what they are signing.

---

## 🧪 Testing Performed

- ✅ **PyMuPDF Extraction**: Tested with digital PDF contracts and character density checks.
- ✅ **Clause Categorization**: Verified across 20 distinct legal clause categories.
- ✅ **Risk & Misleading Detection**: Tested with unilateral termination, Net 90 payment delays, unlimited liability, broad IP assignments, and restrictive covenants.
- ✅ **Multi-Language Generation**: Verified output across Hindi (हिंदी), Hinglish, Bengali, and English.
- ✅ **JWT Authentication & Ownership Isolation**: Verified user registration, token generation, protected routes, and isolation between user contracts.
- ✅ **Cascade File & Data Deletion**: Verified physical disk cleanup and MongoDB document deletion.
- ✅ **Zero Cost & Offline Resilience**: Verified execution without external internet connectivity or paid API keys.

---

## 📄 License

MIT License. Free and open-source for personal and commercial educational use.
