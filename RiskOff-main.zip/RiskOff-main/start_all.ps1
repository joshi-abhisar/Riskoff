# RiskOff All-in-One PowerShell Launcher
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "  Starting RISKOFF - AI Contract Analyzer" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Cyan

Write-Host "`n[1/3] Starting Python FastAPI AI Microservice (Port 8000)..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd ai-service; .\venv\Scripts\activate; python -m uvicorn main:app --reload --port 8000"

Start-Sleep -Seconds 3

Write-Host "[2/3] Starting Node.js Backend API (Port 5000)..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd server; npm run dev"

Start-Sleep -Seconds 2

Write-Host "[3/3] Starting React Frontend UI (Port 5173)..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd client; npm run dev"

Write-Host "`n==================================================" -ForegroundColor Cyan
Write-Host "  All services launched successfully!" -ForegroundColor Green
Write-Host "  Web App:  http://localhost:5173" -ForegroundColor White
Write-Host "  Backend:  http://localhost:5000/api/health" -ForegroundColor White
Write-Host "  AI Micro: http://localhost:8000/health" -ForegroundColor White
Write-Host "==================================================" -ForegroundColor Cyan
