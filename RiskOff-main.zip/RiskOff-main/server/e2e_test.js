/**
 * e2e_test.js - Comprehensive End-to-End Test Suite for RiskOff
 * Tests:
 * 1. Health checks (Node API, MongoDB, Python AI Microservice)
 * 2. User Registration & JWT Authentication
 * 3. Contract PDF Upload
 * 4. Multi-language Contract Analysis (Hindi & Hinglish)
 * 5. Score verification (Risk Indicator & Transparency Score)
 * 6. Clause categorization & Risk detection
 * 7. User Isolation & Privacy Guard
 * 8. Cascading Deletion
 */

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

const API_URL = 'http://127.0.0.1:5000/api';
const AI_URL = 'http://127.0.0.1:8000';

async function runTests() {
  console.log('\n==================================================');
  console.log('  STARTING RISKOFF END-TO-END TEST SUITE');
  console.log('==================================================\n');

  let testPassed = 0;
  let totalTests = 0;

  function assert(condition, message) {
    totalTests++;
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      testPassed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      process.exitCode = 1;
    }
  }

  // 1. Health Check
  console.log('\n[1] Checking System Health Endpoints...');
  try {
    const aiHealth = await axios.get(`${AI_URL}/health`, { timeout: 4000 });
    assert(aiHealth.data.status === 'online', 'FastAPI AI Microservice is online');
    assert(aiHealth.data.configured_ai_provider === 'rule_based', 'AI provider configured as rule_based');

    const nodeHealth = await axios.get(`${API_URL}/health`, { timeout: 4000 });
    assert(nodeHealth.data.status === 'online', 'Node.js Backend is online');
    assert(nodeHealth.data.database.connected === true, 'MongoDB database is connected');
    assert(nodeHealth.data.aiService.status === 'online', 'Node Backend successfully connected to FastAPI service');
  } catch (err) {
    console.error('Health check failed:', err.message);
    process.exit(1);
  }

  // 2. Authentication: Register User 1
  console.log('\n[2] Testing User Registration & Authentication...');
  const testEmail1 = `freelancer_${Date.now()}@test.com`;
  let tokenUser1 = '';
  let user1Id = '';

  try {
    const regRes = await axios.post(`${API_URL}/auth/register`, {
      name: 'Rohan Sharma',
      email: testEmail1,
      password: 'password123',
      confirmPassword: 'password123'
    });
    assert(regRes.data.success === true, 'User 1 registered successfully');
    assert(!!regRes.data.token, 'JWT token issued upon registration');
    tokenUser1 = regRes.data.token;
    user1Id = regRes.data.user.id;

    // Test Login
    const loginRes = await axios.post(`${API_URL}/auth/login`, {
      email: testEmail1,
      password: 'password123'
    });
    assert(loginRes.data.success === true, 'User 1 login successful');

    // Test Get Me
    const meRes = await axios.get(`${API_URL}/auth/me`, {
      headers: { Authorization: `Bearer ${tokenUser1}` }
    });
    assert(meRes.data.user.email === testEmail1, 'Auth me endpoint returned correct user profile');
  } catch (err) {
    console.error('Auth test failed:', err.response?.data || err.message);
    process.exit(1);
  }

  // 3. Upload Sample PDF Contract
  console.log('\n[3] Testing Contract PDF Upload...');
  const pdfPath = path.join(__dirname, '../sample_contracts/sample_freelancer_agreement.pdf');
  let contractId = '';

  try {
    const form = new FormData();
    form.append('file', fs.createReadStream(pdfPath));

    const uploadRes = await axios.post(`${API_URL}/contracts/upload`, form, {
      headers: {
        ...form.getHeaders(),
        Authorization: `Bearer ${tokenUser1}`
      }
    });

    assert(uploadRes.data.success === true, 'PDF contract uploaded successfully');
    assert(uploadRes.data.contract.fileType === 'pdf', 'Contract detected as PDF');
    contractId = uploadRes.data.contract.id;
    assert(!!contractId, `Contract saved with ID: ${contractId}`);
  } catch (err) {
    console.error('Contract upload test failed:', err.response?.data || err.message);
    process.exit(1);
  }

  // 4. Contract Analysis in Hindi (हिंदी)
  console.log('\n[4] Testing Contract Analysis in Hindi (हिंदी)...');
  try {
    const analyzeRes = await axios.post(
      `${API_URL}/analyze/${contractId}`,
      { preferredLanguage: 'hi' },
      { headers: { Authorization: `Bearer ${tokenUser1}` } }
    );

    const a = analyzeRes.data.analysis;
    assert(analyzeRes.data.success === true, 'Contract analysis returned success');
    assert(a.preferredLanguage === 'hi', 'Preferred language recorded as Hindi (hi)');
    assert(a.riskScore >= 50, `Risk Score calculated properly (${a.riskScore}/100)`);
    assert(a.transparencyScore > 0, `Transparency Score calculated properly (${a.transparencyScore}/100)`);
    assert(a.risks.length > 0, `Detected ${a.risks.length} high-risk clauses`);
    assert(a.potentiallyMisleadingClauses.length > 0, `Detected ${a.potentiallyMisleadingClauses.length} potentially misleading clauses`);
    assert(a.importantClauses.length > 0, `Extracted ${a.importantClauses.length} categorized clauses`);
    assert(a.recommendations.length > 0, `Generated ${a.recommendations.length} actionable recommendations`);
    assert(a.summary.includes('अनुबंध') || a.summary.length > 20, 'Hindi executive summary generated accurately');
    
    console.log(`\n    [Sample Hindi Summary Output]:\n    "${a.summary}"\n`);
  } catch (err) {
    console.error('Hindi Analysis test failed:', err.response?.data || err.message);
    process.exit(1);
  }

  // 5. Re-analyze in Hinglish
  console.log('\n[5] Testing Re-analysis in Hinglish...');
  try {
    const reanalyzeRes = await axios.post(
      `${API_URL}/analyze/${contractId}`,
      { preferredLanguage: 'hinglish' },
      { headers: { Authorization: `Bearer ${tokenUser1}` } }
    );

    const aHing = reanalyzeRes.data.analysis;
    assert(aHing.preferredLanguage === 'hinglish', 'Language updated to Hinglish');
    assert(aHing.summary.includes('contract') || aHing.summary.includes('clauses'), 'Hinglish summary generated properly');
    console.log(`    [Sample Hinglish Summary Output]:\n    "${aHing.summary}"\n`);
  } catch (err) {
    console.error('Hinglish Re-analysis test failed:', err.response?.data || err.message);
    process.exit(1);
  }

  // 6. User Isolation & Privacy Test
  console.log('\n[6] Testing User Privacy & Ownership Isolation...');
  const testEmail2 = `creator_${Date.now()}@test.com`;
  let tokenUser2 = '';

  try {
    const regRes2 = await axios.post(`${API_URL}/auth/register`, {
      name: 'Priya Patel',
      email: testEmail2,
      password: 'password123',
      confirmPassword: 'password123'
    });
    tokenUser2 = regRes2.data.token;

    // User 2 tries to access User 1's contract
    let accessDenied = false;
    try {
      await axios.get(`${API_URL}/contracts/${contractId}`, {
        headers: { Authorization: `Bearer ${tokenUser2}` }
      });
    } catch (e) {
      if (e.response?.status === 404 || e.response?.status === 403) {
        accessDenied = true;
      }
    }
    assert(accessDenied, 'User 2 is blocked from accessing User 1 contract (404/403 isolated)');

    // User 2 list should be empty
    const listRes2 = await axios.get(`${API_URL}/contracts`, {
      headers: { Authorization: `Bearer ${tokenUser2}` }
    });
    assert(listRes2.data.contracts.length === 0, 'User 2 contract list is strictly isolated and empty');
  } catch (err) {
    console.error('User isolation test failed:', err.response?.data || err.message);
    process.exit(1);
  }

  // 7. Cascade Deletion
  console.log('\n[7] Testing Cascade Deletion...');
  try {
    const delRes = await axios.delete(`${API_URL}/contracts/${contractId}`, {
      headers: { Authorization: `Bearer ${tokenUser1}` }
    });
    assert(delRes.data.success === true, 'Contract deletion endpoint returned success');

    // Verify contract is gone
    let notFoundAfterDelete = false;
    try {
      await axios.get(`${API_URL}/contracts/${contractId}`, {
        headers: { Authorization: `Bearer ${tokenUser1}` }
      });
    } catch (e) {
      if (e.response?.status === 404) notFoundAfterDelete = true;
    }
    assert(notFoundAfterDelete, 'Contract and analysis permanently purged from database');
  } catch (err) {
    console.error('Cascade deletion test failed:', err.response?.data || err.message);
    process.exit(1);
  }

  console.log('\n==================================================');
  console.log(`  ALL ${testPassed}/${totalTests} TESTS PASSED SUCCESSFULLY!`);
  console.log('==================================================\n');
}

runTests();
