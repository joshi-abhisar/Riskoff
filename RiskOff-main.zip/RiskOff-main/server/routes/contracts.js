const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Contract = require('../models/Contract');
const Analysis = require('../models/Analysis');
const auth = require('../middleware/auth');

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname).toLowerCase();
    const safeBaseName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    cb(null, `${safeBaseName}-${uniqueSuffix}${ext}`);
  }
});

// File filter for security
const fileFilter = (req, file, cb) => {
  const allowedExtensions = ['.pdf', '.png', '.jpg', '.jpeg', '.docx', '.txt'];
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (!allowedExtensions.includes(ext)) {
    return cb(new Error(`Unsupported file type: ${ext}. Only PDF, DOCX, PNG, JPG, and TXT files up to 10MB are permitted.`), false);
  }
  cb(null, true);
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10 MB limit
  }
});

/**
 * POST /api/contracts/upload
 * Upload a contract file (Protected)
 */
router.post('/upload', auth, (req, res) => {
  upload.single('file')(req, res, async (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({
          success: false,
          message: 'File is too large. Maximum permitted file size is 10MB.'
        });
      }
      return res.status(400).json({ success: false, message: `Upload error: ${err.message}` });
    } else if (err) {
      return res.status(400).json({ success: false, message: err.message });
    }

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No contract file was selected or uploaded.'
      });
    }

    try {
      const ext = path.extname(req.file.originalname).toLowerCase().replace('.', '');
      let fileType = 'pdf';
      if (['png', 'jpg', 'jpeg'].includes(ext)) {
        fileType = 'image';
      } else if (ext === 'docx') {
        fileType = 'docx';
      } else if (ext === 'txt') {
        fileType = 'text';
      }

      const contract = new Contract({
        userId: req.user.id,
        fileName: req.file.originalname,
        filePath: req.file.path,
        fileType,
        fileSize: req.file.size,
        status: 'uploaded'
      });

      await contract.save();

      return res.status(201).json({
        success: true,
        message: 'Contract uploaded successfully.',
        contract: {
          id: contract._id,
          fileName: contract.fileName,
          fileType: contract.fileType,
          fileSize: contract.fileSize,
          status: contract.status,
          createdAt: contract.createdAt
        }
      });
    } catch (error) {
      console.error('Contract upload save error:', error);
      // Clean up uploaded file if DB save fails
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(500).json({
        success: false,
        message: 'Failed to record uploaded contract in database.'
      });
    }
  });
});

/**
 * GET /api/contracts
 * List all contracts belonging to authenticated user (Protected)
 */
router.get('/', auth, async (req, res) => {
  try {
    const contracts = await Contract.find({ userId: req.user.id })
      .sort({ createdAt: -1 })
      .lean();

    // Attach analysis summary if exists
    const contractIds = contracts.map(c => c._id);
    const analyses = await Analysis.find({ contractId: { $in: contractIds }, userId: req.user.id })
      .select('contractId riskScore riskLevel transparencyScore preferredLanguage createdAt')
      .lean();

    const analysisMap = {};
    analyses.forEach(a => {
      analysisMap[a.contractId.toString()] = a;
    });

    const contractsWithAnalysis = contracts.map(c => ({
      id: c._id,
      fileName: c.fileName,
      fileType: c.fileType,
      fileSize: c.fileSize,
      status: c.status,
      createdAt: c.createdAt,
      analysis: analysisMap[c._id.toString()] || null
    }));

    return res.status(200).json({
      success: true,
      contracts: contractsWithAnalysis
    });
  } catch (error) {
    console.error('List contracts error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve contracts list.'
    });
  }
});

/**
 * GET /api/contracts/:id
 * Get single contract detail (Protected)
 */
router.get('/:id', auth, async (req, res) => {
  try {
    const contract = await Contract.findOne({ _id: req.params.id, userId: req.user.id });
    if (!contract) {
      return res.status(404).json({
        success: false,
        message: 'Contract not found or access denied.'
      });
    }

    const analysis = await Analysis.findOne({ contractId: contract._id, userId: req.user.id });

    return res.status(200).json({
      success: true,
      contract: {
        id: contract._id,
        fileName: contract.fileName,
        fileType: contract.fileType,
        fileSize: contract.fileSize,
        status: contract.status,
        createdAt: contract.createdAt
      },
      analysis
    });
  } catch (error) {
    console.error('Get contract error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve contract.'
    });
  }
});

/**
 * DELETE /api/contracts/:id
 * Delete contract, associated uploaded file, and analysis record (Protected)
 */
router.delete('/:id', auth, async (req, res) => {
  try {
    const contract = await Contract.findOne({ _id: req.params.id, userId: req.user.id });
    if (!contract) {
      return res.status(404).json({
        success: false,
        message: 'Contract not found or access denied.'
      });
    }

    // Safely delete physical file on disk
    if (contract.filePath && fs.existsSync(contract.filePath)) {
      try {
        fs.unlinkSync(contract.filePath);
      } catch (fileErr) {
        console.warn(`Could not delete file from disk: ${contract.filePath}`, fileErr);
      }
    }

    // Cascade delete Analysis records
    await Analysis.deleteMany({ contractId: contract._id, userId: req.user.id });

    // Delete Contract record
    await Contract.deleteOne({ _id: contract._id });

    return res.status(200).json({
      success: true,
      message: 'Contract and associated analysis permanently deleted.'
    });
  } catch (error) {
    console.error('Delete contract error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete contract.'
    });
  }
});

module.exports = router;
