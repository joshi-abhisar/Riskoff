const express = require('express');
const router = express.Router();
const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const Contract = require('../models/Contract');
const Analysis = require('../models/Analysis');
const auth = require('../middleware/auth');

const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://127.0.0.1:8000';

/**
 * POST /api/analyze/:contractId
 * Triggers contract analysis through the Python FastAPI microservice (Protected)
 */
router.post('/:contractId', auth, async (req, res) => {
  try {
    const { preferredLanguage = 'en' } = req.body;
    const contract = await Contract.findOne({ _id: req.params.contractId, userId: req.user.id });

    if (!contract) {
      return res.status(404).json({
        success: false,
        message: 'Contract not found or access denied.'
      });
    }

    if (!fs.existsSync(contract.filePath)) {
      return res.status(404).json({
        success: false,
        message: 'Contract file is missing from disk storage.'
      });
    }

    contract.status = 'analyzing';
    await contract.save();

    // Prepare multipart form data for FastAPI service
    const form = new FormData();
    form.append('file', fs.createReadStream(contract.filePath), contract.fileName);
    form.append('preferredLanguage', preferredLanguage);

    let aiResponse;
    try {
      aiResponse = await axios.post(`${AI_SERVICE_URL}/analyze`, form, {
        headers: {
          ...form.getHeaders()
        },
        timeout: 90000 // 90 seconds timeout for large OCR documents
      });
    } catch (aiErr) {
      console.error('FastAPI AI Service call failed:', aiErr.message);
      contract.status = 'failed';
      await contract.save();

      const errMsg = aiErr.response?.data?.detail || aiErr.message;
      return res.status(502).json({
        success: false,
        message: `Analysis service error: ${errMsg}. Ensure Python AI microservice is running at ${AI_SERVICE_URL}.`
      });
    }

    const aiData = aiResponse.data;

    // Save or update Analysis in MongoDB
    const analysisDoc = await Analysis.findOneAndUpdate(
      { contractId: contract._id, userId: req.user.id },
      {
        contractId: contract._id,
        userId: req.user.id,
        preferredLanguage: aiData.preferredLanguage || preferredLanguage,
        languageName: aiData.languageName || 'English',
        aiProvider: aiData.aiProvider || 'rule_based',
        summary: aiData.summary || '',
        keyTakeaways: aiData.keyTakeaways || [],
        riskScore: aiData.riskScore || 0,
        riskLevel: aiData.riskLevel || 'LOW RISK',
        transparencyScore: aiData.transparencyScore || 100,
        transparencyLevel: aiData.transparencyLevel || 'HIGH TRANSPARENCY',
        risks: aiData.risks || [],
        potentiallyMisleadingClauses: aiData.potentiallyMisleadingClauses || [],
        importantClauses: aiData.importantClauses || [],
        recommendations: aiData.recommendations || [],
        extractedText: aiData.extractedText || '',
        stats: aiData.stats || {},
        createdAt: new Date()
      },
      { upsert: true, new: true }
    );

    contract.status = 'analyzed';
    await contract.save();

    return res.status(200).json({
      success: true,
      message: 'Contract analysis completed successfully.',
      analysis: analysisDoc
    });
  } catch (error) {
    console.error('Run analysis error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to process contract analysis.'
    });
  }
});

/**
 * GET /api/analyze/:contractId
 * Retrieves existing saved analysis for a contract (Protected)
 */
router.get('/:contractId', auth, async (req, res) => {
  try {
    const analysis = await Analysis.findOne({
      contractId: req.params.contractId,
      userId: req.user.id
    });

    if (!analysis) {
      return res.status(404).json({
        success: false,
        message: 'No analysis found for this contract. Please run analysis first.'
      });
    }

    return res.status(200).json({
      success: true,
      analysis
    });
  } catch (error) {
    console.error('Get analysis error:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve analysis.'
    });
  }
});

module.exports = router;
