const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const axios = require('axios');
const path = require('path');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/riskoff';
const AI_SERVICE_URL = process.env.AI_SERVICE_URL || 'http://127.0.0.1:8000';

// Security Middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));

// CORS Configuration
app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300, // Limit each IP to 300 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many requests from this IP. Please try again in a few minutes.'
  }
});
app.use('/api/', limiter);

// Body Parsers
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ extended: true, limit: '15mb' }));

// Database Connection
let isDbConnected = false;

const connectDB = async () => {
  try {
    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 5000
    });
    isDbConnected = true;
    console.log('MongoDB connected successfully:', MONGODB_URI);
  } catch (err) {
    isDbConnected = false;
    console.error('MongoDB connection error:', err.message);
    console.log('Note: Ensure local MongoDB service is running (or configure MONGODB_URI in server/.env)');
  }
};

connectDB();

mongoose.connection.on('disconnected', () => {
  isDbConnected = false;
  console.warn('MongoDB disconnected. Retrying connection...');
});
mongoose.connection.on('reconnected', () => {
  isDbConnected = true;
  console.log('MongoDB reconnected.');
});

// Health check endpoint
app.get('/api/health', async (req, res) => {
  let aiServiceStatus = 'offline';
  let aiDetails = null;

  try {
    const aiHealth = await axios.get(`${AI_SERVICE_URL}/health`, { timeout: 3000 });
    aiServiceStatus = aiHealth.data?.status === 'online' ? 'online' : 'unhealthy';
    aiDetails = aiHealth.data;
  } catch (e) {
    aiServiceStatus = 'offline';
  }

  res.status(200).json({
    status: 'online',
    app: 'RiskOff Backend API',
    timestamp: new Date().toISOString(),
    database: {
      connected: isDbConnected,
      uri: MONGODB_URI.replace(/\/\/.*@/, '//<credentials>@')
    },
    aiService: {
      status: aiServiceStatus,
      url: AI_SERVICE_URL,
      details: aiDetails
    }
  });
});

// Mount Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/contracts', require('./routes/contracts'));
app.use('/api/analyze', require('./routes/analysis'));

// 404 Route Handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `API Route not found: ${req.method} ${req.originalUrl}`
  });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled server error:', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`=========================================`);
  console.log(`  RISKOFF Backend Server running on port ${PORT}`);
  console.log(`  Health API: http://localhost:${PORT}/api/health`);
  console.log(`=========================================`);
});
