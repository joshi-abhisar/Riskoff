const mongoose = require('mongoose');

const analysisSchema = new mongoose.Schema({
  contractId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contract',
    required: [true, 'Contract ID is required'],
    index: true
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required'],
    index: true
  },
  preferredLanguage: {
    type: String,
    default: 'en',
    trim: true
  },
  languageName: {
    type: String,
    default: 'English'
  },
  aiProvider: {
    type: String,
    default: 'rule_based'
  },
  summary: {
    type: String,
    default: ''
  },
  keyTakeaways: {
    type: [String],
    default: []
  },
  riskScore: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  riskLevel: {
    type: String,
    default: 'LOW RISK'
  },
  transparencyScore: {
    type: Number,
    min: 0,
    max: 100,
    default: 100
  },
  transparencyLevel: {
    type: String,
    default: 'HIGH TRANSPARENCY'
  },
  risks: {
    type: [mongoose.Schema.Types.Mixed],
    default: []
  },
  potentiallyMisleadingClauses: {
    type: [mongoose.Schema.Types.Mixed],
    default: []
  },
  importantClauses: {
    type: [mongoose.Schema.Types.Mixed],
    default: []
  },
  recommendations: {
    type: [String],
    default: []
  },
  extractedText: {
    type: String,
    default: ''
  },
  stats: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Analysis', analysisSchema);
